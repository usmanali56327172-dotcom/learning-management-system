# Learning Management System

A production-grade, full-stack LMS in the spirit of Udemy, Coursera, and Skillshare — built as a
portfolio-quality engineering project. Students browse and enroll in courses, watch structured
video lessons, complete quizzes and assignments, and earn verifiable certificates. Instructors
build curricula and track revenue and engagement. Admins moderate content and oversee the
platform.

This is a real, runnable codebase — not a mockup. Every feature listed below has working backend
routes, a database schema, and a connected frontend.

---

## Tech stack

| Layer          | Choice                                                                 | Why |
|----------------|-------------------------------------------------------------------------|-----|
| Backend        | Node.js, Express, TypeScript                                            | Mature ecosystem, strong typing, fast iteration |
| Database       | PostgreSQL + Prisma ORM                                                 | Relational integrity for enrollments/payments; type-safe queries and migrations |
| Auth           | JWT (short-lived access token + rotating httpOnly refresh cookie)       | Stateless, scalable, resistant to XSS token theft |
| Real-time      | Socket.IO                                                                | Live notifications and messaging |
| Payments       | Stripe Checkout + webhooks                                              | Industry-standard, PCI compliance offloaded to Stripe |
| Frontend       | React 18, TypeScript, Vite                                              | Fast dev server, modern tooling |
| Styling        | Tailwind CSS (custom design system)                                     | Utility-first, easy to keep consistent and themeable (incl. dark mode) |
| Data fetching  | TanStack Query                                                          | Caching, retries, background refetch out of the box |
| State          | Zustand                                                                  | Minimal boilerplate for auth/theme state |
| Testing        | Jest + Supertest                                                         | API-level integration tests |
| Docs           | OpenAPI (swagger-jsdoc + swagger-ui)                                    | Interactive API reference at `/api-docs` |
| Containers     | Docker + docker-compose                                                  | One-command local environment, portable deploys |

## Monorepo layout

```
lms-platform/
├── apps/
│   ├── api/                  # Express + TypeScript backend
│   │   ├── prisma/
│   │   │   ├── schema.prisma # Full data model (20+ models)
│   │   │   └── seed.ts       # Demo data (admin/instructor/student + sample course)
│   │   ├── src/
│   │   │   ├── config/       # env, logger, prisma client
│   │   │   ├── middlewares/  # auth, error handling, validation, rate limiting
│   │   │   ├── modules/      # one folder per domain (auth, courses, payments, ...)
│   │   │   │   └── <name>/
│   │   │   │       ├── *.routes.ts
│   │   │   │       ├── *.controller.ts
│   │   │   │       ├── *.service.ts     # business logic, talks to Prisma
│   │   │   │       └── *.validation.ts  # Zod request schemas
│   │   │   ├── realtime/     # Socket.IO server
│   │   │   ├── routes/       # route aggregator
│   │   │   ├── docs/         # OpenAPI spec
│   │   │   ├── app.ts        # Express app wiring
│   │   │   └── index.ts      # HTTP server bootstrap
│   │   └── tests/            # Jest + Supertest integration tests
│   └── web/                   # React + TypeScript frontend
│       └── src/
│           ├── api/           # typed API client modules (axios)
│           ├── components/
│           │   ├── ui/        # Button, Input, Card, Modal, Badge, ProgressBar, ...
│           │   └── layout/    # Navbar, Footer, DashboardLayout, ProtectedRoute
│           ├── pages/         # route-level pages, grouped by student/instructor/admin/shared
│           ├── store/         # Zustand stores (auth, theme)
│           ├── hooks/         # useAuth, etc.
│           └── styles/        # Tailwind entry + design tokens
├── docs/                      # Architecture, API, deployment docs
├── docker-compose.yml
└── README.md
```

Each backend module follows the same layered pattern: **routes → controller → service → Prisma**.
Routes only wire up middleware; controllers only translate HTTP ⇄ service calls; all business
logic and database access lives in the service layer. This keeps modules testable and easy to
reason about in isolation.

---

## Feature checklist

- **Authentication** — register/login with bcrypt-hashed passwords, JWT access + rotating refresh
  tokens (httpOnly cookie), forgot/reset password, protected routes.
- **Role-based dashboards** — distinct Student, Instructor, and Admin experiences with route
  guards on both the API (`authorize()` middleware) and the frontend (`ProtectedRoute`).
- **Course creation** — instructors create draft courses, build a curriculum of sections and
  lessons, then submit for admin review before publishing.
- **Video lessons** — lesson types for video, article, quiz, and assignment; preview lessons for
  non-enrolled visitors.
- **Assignments** — instructor-authored briefs, student file/link submissions, instructor grading
  with feedback.
- **Quizzes** — multiple-choice quizzes with auto-graded attempts and pass/fail thresholds,
  taken directly in the course player (passing a quiz auto-marks the lesson complete).
- **Certificates** — auto-issued on 100% course completion, each with a unique serial number and
  a public verification endpoint.
- **Progress tracking** — per-lesson completion and watch-time, rolled up into an enrollment-level
  percentage.
- **Bookmarks** — timestamped notes on any lesson.
- **Wishlist** — save courses for later.
- **Reviews & ratings** — one review per enrolled student per course; course rating aggregates
  recompute automatically.
- **Course search** — full-text-ish search (title/tags/description), filters (category, level,
  price), and sorting (newest, popular, rating, price).
- **Payments** — Stripe Checkout for paid courses, webhook-driven enrollment fulfillment, payment
  history.
- **Notifications** — persisted notifications pushed live over Socket.IO (enrollment, new review,
  assignment graded, certificate issued, payment, course approved/rejected, new message).
- **Messaging** — a full chat UI (conversation list + thread) with real-time delivery over
  Socket.IO; students can message an instructor directly from any course page.
- **Analytics & reports** — instructor revenue/enrollment/rating dashboards; admin platform-wide
  metrics (users, courses, revenue, signup trend).
- **Admin management** — user search/suspend/role-change, course moderation queue with
  approve/reject + reason, immutable audit log of admin actions.
- **Responsive design & dark mode** — mobile-first Tailwind layout, class-based dark mode with a
  persisted preference.
- **Landing page** — a designed marketing page, not a placeholder.
- **Profile management** — edit name, headline, bio, avatar; change password.

---

## Getting started

### Option A — Docker (recommended, fastest path to a running app)

```bash
git clone <this-repo>
cd lms-platform
cp apps/api/.env.example apps/api/.env   # fill in secrets (see below)
docker compose up --build
```

- API: http://localhost:5000 (docs at `/api-docs`)
- Web: http://localhost:8080
- Postgres: localhost:5432

The `api` service runs `prisma migrate deploy` automatically on boot. To load demo data:

```bash
docker compose exec api npm run prisma:seed
```

### Option B — Run locally without Docker

**Prerequisites:** Node.js 20+, PostgreSQL 16+ (or a hosted instance like Supabase/Neon/Railway).

```bash
# 1. Backend
cd apps/api
cp .env.example .env        # set DATABASE_URL, JWT secrets, Stripe keys
npm install
npx prisma migrate dev      # creates tables
npm run prisma:seed         # optional demo data
npm run dev                 # http://localhost:5000

# 2. Frontend (in a second terminal)
cd apps/web
npm install
npm run dev                 # http://localhost:5173
```

The Vite dev server proxies `/api` to `http://localhost:5000` (see `vite.config.ts`), so the
frontend works out of the box against the local API.

### Demo accounts (after seeding)

| Role       | Email                | Password       |
|------------|-----------------------|----------------|
| Admin      | admin@lms.com         | Password123!   |
| Instructor | instructor@lms.com    | Password123!   |
| Student    | student@lms.com       | Password123!   |

### Required environment variables

See `apps/api/.env.example` for the full list. At minimum for local dev:

- `DATABASE_URL` — Postgres connection string
- `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET` — any long random strings
- `CLIENT_URL` — where the frontend runs (used for CORS + Stripe redirect URLs)

Stripe and SMTP variables are optional for browsing/enrolling in **free** courses; they're only
required to exercise paid checkout and transactional email.

---

## Testing

```bash
cd apps/api
npm test
```

Tests use Supertest against the real Express app (`createApp()`) and assume a reachable test
database via `DATABASE_URL`. In CI, point that at a disposable Postgres service (see
`docs/DEPLOYMENT.md` for a sample GitHub Actions job).

---

## API documentation

Once the API is running, open **http://localhost:5000/api-docs** for an interactive Swagger UI.
See also [`docs/API.md`](./docs/API.md) for a plain-text endpoint reference.

---

## Further reading

- [`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md) — data model, request flow, and key design
  decisions (why JWT rotation, why a service layer, how progress/certificates are derived).
- [`docs/API.md`](./docs/API.md) — endpoint-by-endpoint reference.
- [`docs/DEPLOYMENT.md`](./docs/DEPLOYMENT.md) — deploying to Railway/Render/Fly.io + Vercel, plus
  a CI pipeline sketch.

## Honest scope notes

This project is built to demonstrate real full-stack engineering ability, not to be a literal
Udemy clone overnight. A few things worth knowing before you demo it:

- **Video hosting**: lessons store a `videoUrl` and play it directly; there's no built-in
  transcoding/adaptive-bitrate pipeline (in production you'd put this behind Mux, Cloudflare
  Stream, or S3 + CloudFront).
- **File uploads**: thumbnail/avatar/resource URLs are stored as plain strings; wiring up direct
  browser uploads to S3-compatible storage is a natural next step (a `multer` dependency is
  already included for a local-disk implementation).
- **Email delivery**: `nodemailer` is installed and the reset-password flow generates a token, but
  actually sending mail requires SMTP credentials you provide.
- **Search**: uses Postgres `ILIKE`/array-contains filters, which is fine at portfolio scale;
  swap in Postgres full-text search or Meilisearch/Algolia if you need relevance ranking at scale.

Calling these out up front is more credible than pretending they don't exist — and they're good
answers to "what would you do differently in production?" in an interview.
