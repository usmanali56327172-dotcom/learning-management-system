import { useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";
import { useAuthStore } from "@/store/authStore";

/**
 * Opens a single authenticated Socket.IO connection for the lifetime of the
 * consuming component, and tears it down on unmount. The server expects the
 * access token in the handshake `auth` payload (see api/src/realtime/socket.ts).
 */
export function useSocket(handlers?: Record<string, (payload: any) => void>) {
  const accessToken = useAuthStore((s) => s.accessToken);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!accessToken) return;

    const socket = io("/", { auth: { token: accessToken }, transports: ["websocket"] });
    socketRef.current = socket;

    if (handlers) {
      Object.entries(handlers).forEach(([event, handler]) => socket.on(event, handler));
    }

    return () => {
      socket.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accessToken]);

  return socketRef;
}
