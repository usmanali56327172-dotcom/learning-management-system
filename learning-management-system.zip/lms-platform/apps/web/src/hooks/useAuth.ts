import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { authApi } from "@/api/auth";
import { useAuthStore } from "@/store/authStore";

export function useLogin() {
  const setSession = useAuthStore((s) => s.setSession);
  const navigate = useNavigate();

  return useMutation({
    mutationFn: (payload: { email: string; password: string }) => authApi.login(payload),
    onSuccess: (res) => {
      setSession(res.data.user, res.data.accessToken);
      toast.success("Welcome back!");
      const role = res.data.user.role;
      navigate(role === "ADMIN" ? "/admin" : role === "INSTRUCTOR" ? "/instructor" : "/dashboard");
    },
    onError: (err: any) => {
      toast.error(err?.response?.data?.message || "Login failed");
    },
  });
}

export function useRegister() {
  const setSession = useAuthStore((s) => s.setSession);
  const navigate = useNavigate();

  return useMutation({
    mutationFn: (payload: { firstName: string; lastName: string; email: string; password: string; role?: string }) =>
      authApi.register(payload),
    onSuccess: (res) => {
      setSession(res.data.user, res.data.accessToken);
      toast.success("Account created — welcome!");
      const role = res.data.user.role;
      navigate(role === "INSTRUCTOR" ? "/instructor" : "/dashboard");
    },
    onError: (err: any) => {
      toast.error(err?.response?.data?.message || "Registration failed");
    },
  });
}

export function useLogout() {
  const clearSession = useAuthStore((s) => s.clearSession);
  const navigate = useNavigate();
  return async () => {
    try {
      await authApi.logout();
    } finally {
      clearSession();
      navigate("/");
    }
  };
}
