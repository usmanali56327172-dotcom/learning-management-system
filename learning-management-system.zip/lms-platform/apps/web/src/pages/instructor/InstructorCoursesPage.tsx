import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import toast from "react-hot-toast";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { PageSpinner } from "@/components/ui/Spinner";
import { coursesApi } from "@/api/courses";

const STATUS_TONE: Record<string, "neutral" | "gold" | "forest" | "clay"> = {
  DRAFT: "neutral",
  PENDING_REVIEW: "gold",
  PUBLISHED: "forest",
  REJECTED: "clay",
  ARCHIVED: "neutral",
};

export function InstructorCoursesPage() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["instructor-courses"], queryFn: coursesApi.myCourses });
  const courses = data?.data || [];

  const createDraft = useMutation({
    mutationFn: () =>
      coursesApi.create({
        title: "Untitled course",
        description: "Add a description that tells students what they'll learn.",
      }),
    onSuccess: () => {
      toast.success("Draft course created");
      queryClient.invalidateQueries({ queryKey: ["instructor-courses"] });
    },
  });

  if (isLoading) return <PageSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">My courses</h1>
        <Button onClick={() => createDraft.mutate()} isLoading={createDraft.isPending}>
          <Plus className="h-4 w-4" /> New course
        </Button>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {courses.map((c: any) => (
          <Link key={c.id} to={`/instructor/courses/${c.id}/edit`}>
            <Card className="p-4">
              <div className="flex items-start justify-between">
                <h3 className="font-semibold">{c.title}</h3>
                <Badge tone={STATUS_TONE[c.status]}>{c.status.replace("_", " ")}</Badge>
              </div>
              <p className="mt-2 text-sm text-ink/50 dark:text-parchment/50">
                {c.enrollmentCount} students · ${c.price}
              </p>
            </Card>
          </Link>
        ))}
        {courses.length === 0 && (
          <Card className="p-8 text-center text-sm text-ink/50 dark:text-parchment/50 sm:col-span-2">
            You haven't created any courses yet.
          </Card>
        )}
      </div>
    </div>
  );
}
