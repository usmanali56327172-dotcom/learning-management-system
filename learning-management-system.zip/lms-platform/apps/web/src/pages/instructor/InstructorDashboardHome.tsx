import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { Card } from "@/components/ui/Card";
import { PageSpinner } from "@/components/ui/Spinner";
import { analyticsApi } from "@/api/misc";
import { useAuthStore } from "@/store/authStore";

export function InstructorDashboardHome() {
  const user = useAuthStore((s) => s.user);
  const { data, isLoading } = useQuery({ queryKey: ["instructor-analytics"], queryFn: analyticsApi.instructor });
  const stats = data?.data;

  if (isLoading) return <PageSpinner />;

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Welcome back, {user?.firstName}</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">Here's how your courses are performing.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">Total students</p>
          <p className="mt-1 font-display text-3xl font-semibold">{stats?.totalStudents ?? 0}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">Published courses</p>
          <p className="mt-1 font-display text-3xl font-semibold">{stats?.publishedCourses ?? 0}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">Total revenue</p>
          <p className="mt-1 font-display text-3xl font-semibold">${Number(stats?.totalRevenue || 0).toFixed(2)}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">Reviews</p>
          <p className="mt-1 font-display text-3xl font-semibold">{stats?.totalReviews ?? 0}</p>
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <h2 className="font-semibold">Enrollment trend</h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats?.enrollmentTrend || []}>
              <XAxis dataKey="month" fontSize={12} stroke="currentColor" />
              <YAxis fontSize={12} stroke="currentColor" allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#C9A227" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="mt-6 overflow-hidden">
        <h2 className="p-6 pb-0 font-semibold">Course performance</h2>
        <table className="mt-4 w-full text-sm">
          <thead>
            <tr className="border-b border-ink/10 text-left text-xs uppercase text-ink/50 dark:border-night-border dark:text-parchment/50">
              <th className="px-6 py-2">Course</th>
              <th className="px-6 py-2">Status</th>
              <th className="px-6 py-2">Students</th>
              <th className="px-6 py-2">Rating</th>
            </tr>
          </thead>
          <tbody>
            {stats?.coursePerformance?.map((c: any) => (
              <tr key={c.id} className="border-b border-ink/5 dark:border-night-border">
                <td className="px-6 py-3">{c.title}</td>
                <td className="px-6 py-3">{c.status}</td>
                <td className="px-6 py-3">{c.enrollmentCount}</td>
                <td className="px-6 py-3">{c.averageRating?.toFixed(1) || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
