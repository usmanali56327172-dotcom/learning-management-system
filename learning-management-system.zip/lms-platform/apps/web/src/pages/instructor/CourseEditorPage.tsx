import { useState } from "react";
import { useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { Plus, Send, HelpCircle, ClipboardList, PlayCircle, FileText } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { PageSpinner } from "@/components/ui/Spinner";
import { QuizAuthorModal } from "@/components/instructor/QuizAuthorModal";
import { AssignmentAuthorModal } from "@/components/instructor/AssignmentAuthorModal";
import { GradeSubmissionsModal } from "@/components/instructor/GradeSubmissionsModal";
import { apiClient } from "@/api/client";
import { coursesApi } from "@/api/courses";

type LessonType = "VIDEO" | "ARTICLE" | "QUIZ" | "ASSIGNMENT";

const LESSON_TYPE_ICON: Record<LessonType, any> = {
  VIDEO: PlayCircle,
  ARTICLE: FileText,
  QUIZ: HelpCircle,
  ASSIGNMENT: ClipboardList,
};

interface LessonDraft {
  title: string;
  type: LessonType;
  videoUrl: string;
}

const BLANK_DRAFT: LessonDraft = { title: "", type: "VIDEO", videoUrl: "" };

export function CourseEditorPage() {
  const { id } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const [newSectionTitle, setNewSectionTitle] = useState("");
  const [lessonDrafts, setLessonDrafts] = useState<Record<string, LessonDraft>>({});
  const [authoringLesson, setAuthoringLesson] = useState<{ lessonId: string; type: "QUIZ" | "ASSIGNMENT" } | null>(null);
  const [gradingAssignment, setGradingAssignment] = useState<{ assignmentId: string; maxScore: number } | null>(null);

  // The API doesn't expose "get course by id" for owners directly; instructor course list
  // includes the metadata needed, and we fetch full detail via the public slug-based endpoint
  // once published. For editing, we re-fetch the instructor's course list and find by id.
  const { data: coursesData, isLoading } = useQuery({ queryKey: ["instructor-courses"], queryFn: coursesApi.myCourses });
  const course = coursesData?.data?.find((c: any) => c.id === id);

  const updateCourse = useMutation({
    mutationFn: (payload: any) => coursesApi.update(id!, payload),
    onSuccess: () => {
      toast.success("Course updated");
      queryClient.invalidateQueries({ queryKey: ["instructor-courses"] });
    },
  });

  const addSection = useMutation({
    mutationFn: () => coursesApi.addSection(id!, { title: newSectionTitle }),
    onSuccess: () => {
      setNewSectionTitle("");
      queryClient.invalidateQueries({ queryKey: ["instructor-courses"] });
      queryClient.invalidateQueries({ queryKey: ["course-sections", id] });
    },
  });

  const addLesson = useMutation({
    mutationFn: ({ sectionId, draft }: { sectionId: string; draft: LessonDraft }) =>
      coursesApi.addLesson(sectionId, {
        title: draft.title,
        type: draft.type,
        ...(draft.type === "VIDEO" && draft.videoUrl ? { videoUrl: draft.videoUrl } : {}),
      }),
    onSuccess: (res, variables) => {
      queryClient.invalidateQueries({ queryKey: ["course-sections", id] });
      // If it's a quiz or assignment, immediately prompt the instructor to fill in the content.
      if (variables.draft.type === "QUIZ" || variables.draft.type === "ASSIGNMENT") {
        setAuthoringLesson({ lessonId: res.data.id, type: variables.draft.type });
      }
    },
  });

  const submitForReview = useMutation({
    mutationFn: () => coursesApi.submitForReview(id!),
    onSuccess: () => {
      toast.success("Submitted for admin review");
      queryClient.invalidateQueries({ queryKey: ["instructor-courses"] });
    },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Could not submit"),
  });

  // Fetch full section/lesson tree via the public detail endpoint once we know the slug.
  const { data: detail } = useQuery({
    queryKey: ["course-sections", id],
    queryFn: () => apiClient.get(`/courses/${course.slug}`).then((r) => r.data),
    enabled: !!course?.slug,
  });
  const sections = detail?.data?.sections || [];

  const getDraft = (sectionId: string): LessonDraft => lessonDrafts[sectionId] || BLANK_DRAFT;
  const setDraft = (sectionId: string, patch: Partial<LessonDraft>) =>
    setLessonDrafts({ ...lessonDrafts, [sectionId]: { ...getDraft(sectionId), ...patch } });

  if (isLoading) return <PageSpinner />;
  if (!course) return <p>Course not found.</p>;

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">Edit course</h1>
        <div className="flex items-center gap-2">
          <Badge>{course.status.replace("_", " ")}</Badge>
          <Button onClick={() => submitForReview.mutate()} isLoading={submitForReview.isPending} disabled={course.status !== "DRAFT"}>
            <Send className="h-4 w-4" /> Submit for review
          </Button>
        </div>
      </div>

      <Card className="mt-6 p-6">
        <h2 className="font-semibold">Course details</h2>
        <form
          className="mt-4 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            const form = new FormData(e.currentTarget);
            updateCourse.mutate({
              title: form.get("title"),
              subtitle: form.get("subtitle"),
              description: form.get("description"),
              price: Number(form.get("price")),
            });
          }}
        >
          <Input name="title" label="Title" defaultValue={course.title} />
          <Input name="subtitle" label="Subtitle" defaultValue={course.subtitle} />
          <div>
            <label className="mb-1.5 block text-sm font-medium">Description</label>
            <textarea
              name="description"
              rows={4}
              defaultValue={course.description}
              className="w-full rounded-lg border border-ink/15 bg-white px-3.5 py-2.5 text-sm dark:border-night-border dark:bg-night-surface"
            />
          </div>
          <Input name="price" type="number" step="0.01" label="Price (USD)" defaultValue={course.price} />
          <Button type="submit" isLoading={updateCourse.isPending}>Save changes</Button>
        </form>
      </Card>

      <Card className="mt-6 p-6">
        <h2 className="font-semibold">Curriculum</h2>

        <div className="mt-4 space-y-4">
          {sections.map((section: any) => (
            <div key={section.id} className="rounded-lg border border-ink/10 p-4 dark:border-night-border">
              <h3 className="font-medium">{section.title}</h3>
              <ul className="mt-2 space-y-1.5 text-sm text-ink/60 dark:text-parchment/60">
                {section.lessons.map((lesson: any) => {
                  const Icon = LESSON_TYPE_ICON[lesson.type as LessonType] || PlayCircle;
                  const needsAuthoring = (lesson.type === "QUIZ" || lesson.type === "ASSIGNMENT");
                  return (
                    <li key={lesson.id} className="flex items-center gap-2">
                      <Icon className="h-3.5 w-3.5 shrink-0" />
                      {lesson.title}
                      {needsAuthoring && (
                        <button
                          className="ml-auto text-xs text-forest hover:underline dark:text-forest-light"
                          onClick={() => setAuthoringLesson({ lessonId: lesson.id, type: lesson.type })}
                        >
                          {lesson.type === "QUIZ" ? "Edit questions" : "Edit brief"}
                        </button>
                      )}
                      {lesson.type === "ASSIGNMENT" && lesson.assignment && (
                        <button
                          className="text-xs text-ink/50 hover:underline dark:text-parchment/50"
                          onClick={() =>
                            setGradingAssignment({ assignmentId: lesson.assignment.id, maxScore: lesson.assignment.maxScore })
                          }
                        >
                          Submissions
                        </button>
                      )}
                    </li>
                  );
                })}
              </ul>

              <div className="mt-3 space-y-2 rounded-lg bg-parchment/40 p-3 dark:bg-night-bg/40">
                <div className="flex gap-2">
                  <input
                    placeholder="New lesson title"
                    value={getDraft(section.id).title}
                    onChange={(e) => setDraft(section.id, { title: e.target.value })}
                    className="flex-1 rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm dark:border-night-border dark:bg-night-surface"
                  />
                  <select
                    value={getDraft(section.id).type}
                    onChange={(e) => setDraft(section.id, { type: e.target.value as LessonType })}
                    className="rounded-lg border border-ink/15 bg-white px-2 py-1.5 text-sm dark:border-night-border dark:bg-night-surface"
                  >
                    <option value="VIDEO">Video</option>
                    <option value="ARTICLE">Article</option>
                    <option value="QUIZ">Quiz</option>
                    <option value="ASSIGNMENT">Assignment</option>
                  </select>
                </div>
                {getDraft(section.id).type === "VIDEO" && (
                  <input
                    placeholder="Video URL (optional — can add later)"
                    value={getDraft(section.id).videoUrl}
                    onChange={(e) => setDraft(section.id, { videoUrl: e.target.value })}
                    className="w-full rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm dark:border-night-border dark:bg-night-surface"
                  />
                )}
                <Button
                  size="sm"
                  variant="outline"
                  isLoading={addLesson.isPending}
                  onClick={() => {
                    const draft = getDraft(section.id);
                    if (!draft.title) return;
                    addLesson.mutate({ sectionId: section.id, draft });
                    setLessonDrafts({ ...lessonDrafts, [section.id]: BLANK_DRAFT });
                  }}
                >
                  <Plus className="h-3.5 w-3.5" /> Add lesson
                </Button>
                <p className="text-xs text-ink/40 dark:text-parchment/40">
                  Quiz and assignment lessons open a follow-up form to fill in questions or instructions.
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex gap-2">
          <input
            placeholder="New section title"
            value={newSectionTitle}
            onChange={(e) => setNewSectionTitle(e.target.value)}
            className="flex-1 rounded-lg border border-ink/15 bg-white px-3 py-2 text-sm dark:border-night-border dark:bg-night-surface"
          />
          <Button onClick={() => addSection.mutate()} isLoading={addSection.isPending} disabled={!newSectionTitle}>
            <Plus className="h-4 w-4" /> Add section
          </Button>
        </div>
      </Card>

      {authoringLesson?.type === "QUIZ" && (
        <QuizAuthorModal
          isOpen
          onClose={() => setAuthoringLesson(null)}
          lessonId={authoringLesson.lessonId}
          onCreated={() => queryClient.invalidateQueries({ queryKey: ["course-sections", id] })}
        />
      )}
      {authoringLesson?.type === "ASSIGNMENT" && (
        <AssignmentAuthorModal
          isOpen
          onClose={() => setAuthoringLesson(null)}
          lessonId={authoringLesson.lessonId}
          onCreated={() => queryClient.invalidateQueries({ queryKey: ["course-sections", id] })}
        />
      )}
      {gradingAssignment && (
        <GradeSubmissionsModal
          isOpen
          onClose={() => setGradingAssignment(null)}
          assignmentId={gradingAssignment.assignmentId}
          maxScore={gradingAssignment.maxScore}
        />
      )}
    </div>
  );
}
