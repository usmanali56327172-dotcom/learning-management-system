import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";
import { GraduationCap } from "lucide-react";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useLogin } from "@/hooks/useAuth";

interface FormData {
  email: string;
  password: string;
}

export function LoginPage() {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>();
  const login = useLogin();

  return (
    <div className="flex min-h-screen items-center justify-center bg-parchment/30 px-4 dark:bg-night-bg">
      <div className="w-full max-w-sm">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2 font-display text-xl font-semibold">
          <GraduationCap className="h-6 w-6 text-gold" /> LMS
        </Link>
        <div className="rounded-2xl border border-ink/10 bg-white p-8 shadow-card dark:border-night-border dark:bg-night-surface">
          <h1 className="font-display text-2xl font-semibold">Welcome back</h1>
          <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">Sign in to continue learning.</p>

          <form className="mt-6 space-y-4" onSubmit={handleSubmit((data) => login.mutate(data))}>
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              error={errors.email?.message}
              {...register("email", { required: "Email is required" })}
            />
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              error={errors.password?.message}
              {...register("password", { required: "Password is required" })}
            />
            <div className="flex justify-end">
              <Link to="/forgot-password" className="text-xs text-forest hover:underline dark:text-forest-light">
                Forgot password?
              </Link>
            </div>
            <Button type="submit" className="w-full" isLoading={login.isPending}>
              Sign in
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-ink/60 dark:text-parchment/60">
            New to the platform?{" "}
            <Link to="/register" className="font-medium text-forest hover:underline dark:text-forest-light">
              Create an account
            </Link>
          </p>
        </div>

        <div className="mt-4 rounded-lg bg-gold/10 p-3 text-center text-xs text-ink/60 dark:text-parchment/60">
          Demo accounts — password <code className="font-mono">Password123!</code><br />
          admin@lms.com · instructor@lms.com · student@lms.com
        </div>
      </div>
    </div>
  );
}
