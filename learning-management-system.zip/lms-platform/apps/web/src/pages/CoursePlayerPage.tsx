import { useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Circle, ChevronLeft, PlayCircle, FileText, HelpCircle, ClipboardList } from "lucide-react";
import clsx from "clsx";
import { Navbar } from "@/components/layout/Navbar";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { Button } from "@/components/ui/Button";
import { PageSpinner } from "@/components/ui/Spinner";
import { QuizBlock } from "@/components/course-player/QuizBlock";
import { AssignmentBlock } from "@/components/course-player/AssignmentBlock";
import { enrollmentsApi, progressApi } from "@/api/enrollments";

const LESSON_ICON: Record<string, any> = {
  VIDEO: PlayCircle,
  ARTICLE: FileText,
  QUIZ: HelpCircle,
  ASSIGNMENT: ClipboardList,
};

export function CoursePlayerPage() {
  const { slug } = useParams<{ slug: string }>();
  const queryClient = useQueryClient();
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["learn", slug],
    queryFn: () => enrollmentsApi.learn(slug!),
    enabled: !!slug,
  });

  const markComplete = useMutation({
    mutationFn: (lessonId: string) => progressApi.markLesson(lessonId, { isCompleted: true }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["learn", slug] }),
  });

  const course = data?.data?.course;
  const enrollment = data?.data?.enrollment;
  const progressRecords: any[] = data?.data?.progress || [];

  const allLessons = useMemo(
    () => course?.sections?.flatMap((s: any) => s.lessons.map((l: any) => ({ ...l, sectionTitle: s.title }))) || [],
    [course]
  );

  const activeLesson = allLessons.find((l: any) => l.id === activeLessonId) || allLessons[0];
  const isLessonComplete = (id: string) => progressRecords.find((p) => p.lessonId === id)?.isCompleted;

  if (isLoading) return <PageSpinner />;
  if (!course) return null;

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <div className="flex flex-1 flex-col lg:flex-row">
        {/* Lesson content */}
        <main className="flex-1 bg-ink">
          <div className="aspect-video w-full bg-black">
            {activeLesson?.type === "VIDEO" && activeLesson?.videoUrl ? (
              <video key={activeLesson.id} controls className="h-full w-full">
                <source src={activeLesson.videoUrl} />
              </video>
            ) : (
              <div className="flex h-full items-center justify-center text-paper/50">
                {activeLesson ? `${activeLesson.type} content` : "Select a lesson to begin"}
              </div>
            )}
          </div>
          <div className="bg-paper p-6 dark:bg-night-bg">
            <Link to={`/courses/${slug}`} className="flex items-center gap-1 text-sm text-ink/50 hover:underline dark:text-parchment/50">
              <ChevronLeft className="h-4 w-4" /> Back to course overview
            </Link>
            <h1 className="mt-2 font-display text-2xl font-semibold">{activeLesson?.title}</h1>
            <p className="mt-1 text-sm text-ink/50 dark:text-parchment/50">{activeLesson?.sectionTitle}</p>

            {activeLesson?.type === "ARTICLE" && (
              <div className="mt-4 whitespace-pre-wrap text-sm leading-relaxed">{activeLesson.articleContent}</div>
            )}

            {activeLesson?.type === "QUIZ" && (
              <div className="mt-4">
                <QuizBlock lessonId={activeLesson.id} onPassed={() => markComplete.mutate(activeLesson.id)} />
              </div>
            )}

            {activeLesson?.type === "ASSIGNMENT" && activeLesson.assignment && (
              <div className="mt-4">
                <AssignmentBlock
                  assignmentId={activeLesson.assignment.id}
                  title={activeLesson.assignment.title}
                  instructions={activeLesson.assignment.instructions}
                  maxScore={activeLesson.assignment.maxScore}
                />
              </div>
            )}

            {activeLesson && (activeLesson.type === "VIDEO" || activeLesson.type === "ARTICLE") && (
              <Button
                className="mt-6"
                disabled={isLessonComplete(activeLesson.id)}
                onClick={() => markComplete.mutate(activeLesson.id)}
                isLoading={markComplete.isPending}
              >
                {isLessonComplete(activeLesson.id) ? "Completed" : "Mark as complete"}
              </Button>
            )}
          </div>
        </main>

        {/* Curriculum sidebar */}
        <aside className="w-full shrink-0 border-l border-ink/10 bg-white dark:border-night-border dark:bg-night-surface lg:w-96">
          <div className="border-b border-ink/10 p-5 dark:border-night-border">
            <h2 className="font-display text-lg font-semibold">{course.title}</h2>
            <div className="mt-3 flex items-center gap-2">
              <ProgressBar value={enrollment?.progressPct || 0} className="flex-1" />
              <span className="text-xs font-medium text-ink/60 dark:text-parchment/60">{enrollment?.progressPct || 0}%</span>
            </div>
          </div>
          <div className="max-h-[calc(100vh-220px)] overflow-y-auto">
            {course.sections.map((section: any) => (
              <div key={section.id}>
                <p className="bg-parchment/50 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-ink/50 dark:bg-night-bg/50 dark:text-parchment/50">
                  {section.title}
                </p>
                {section.lessons.map((lesson: any) => {
                  const Icon = LESSON_ICON[lesson.type] || PlayCircle;
                  const complete = isLessonComplete(lesson.id);
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => setActiveLessonId(lesson.id)}
                      className={clsx(
                        "flex w-full items-center gap-3 px-4 py-3 text-left text-sm transition-colors",
                        activeLesson?.id === lesson.id
                          ? "bg-gold/10 font-medium"
                          : "hover:bg-ink/5 dark:hover:bg-white/5"
                      )}
                    >
                      {complete ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-forest dark:text-forest-light" />
                      ) : (
                        <Circle className="h-4 w-4 shrink-0 text-ink/30 dark:text-parchment/30" />
                      )}
                      <Icon className="h-4 w-4 shrink-0 text-ink/40 dark:text-parchment/40" />
                      <span className="line-clamp-1">{lesson.title}</span>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
