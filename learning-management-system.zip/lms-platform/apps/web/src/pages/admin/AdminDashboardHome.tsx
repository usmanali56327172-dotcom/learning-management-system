import { useQuery } from "@tanstack/react-query";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { Card } from "@/components/ui/Card";
import { PageSpinner } from "@/components/ui/Spinner";
import { analyticsApi } from "@/api/misc";

export function AdminDashboardHome() {
  const { data, isLoading } = useQuery({ queryKey: ["admin-analytics"], queryFn: analyticsApi.admin });
  const stats = data?.data;

  if (isLoading) return <PageSpinner />;

  const cards = [
    { label: "Total users", value: stats?.totalUsers },
    { label: "Students", value: stats?.totalStudents },
    { label: "Instructors", value: stats?.totalInstructors },
    { label: "Published courses", value: stats?.publishedCourses },
    { label: "Total enrollments", value: stats?.totalEnrollments },
    { label: "Platform revenue", value: `$${Number(stats?.totalRevenue || 0).toFixed(2)}` },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Platform overview</h1>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <Card key={c.label} className="p-5">
            <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">{c.label}</p>
            <p className="mt-1 font-display text-3xl font-semibold">{c.value ?? 0}</p>
          </Card>
        ))}
      </div>

      <Card className="mt-6 p-6">
        <h2 className="font-semibold">Signup trend</h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={stats?.signupTrend || []}>
              <XAxis dataKey="month" fontSize={12} stroke="currentColor" />
              <YAxis fontSize={12} stroke="currentColor" allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#1B4332" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
