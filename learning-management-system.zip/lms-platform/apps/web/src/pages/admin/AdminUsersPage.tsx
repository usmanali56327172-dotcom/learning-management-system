import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { PageSpinner } from "@/components/ui/Spinner";
import { adminApi } from "@/api/misc";

export function AdminUsersPage() {
  const [search, setSearch] = useState("");
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-users", search],
    queryFn: () => adminApi.listUsers({ search, limit: 20 }),
  });

  const toggleActive = useMutation({
    mutationFn: ({ userId, isActive }: { userId: string; isActive: boolean }) => adminApi.setUserActive(userId, isActive),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-users"] }),
  });

  const users = data?.data || [];

  if (isLoading) return <PageSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">Users</h1>
        <input
          placeholder="Search users..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="rounded-lg border border-ink/15 bg-white px-3 py-2 text-sm dark:border-night-border dark:bg-night-surface"
        />
      </div>

      <Card className="mt-6 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink/10 text-left text-xs uppercase text-ink/50 dark:border-night-border dark:text-parchment/50">
              <th className="px-6 py-3">Name</th>
              <th className="px-6 py-3">Email</th>
              <th className="px-6 py-3">Role</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u: any) => (
              <tr key={u.id} className="border-b border-ink/5 dark:border-night-border">
                <td className="px-6 py-3">{u.firstName} {u.lastName}</td>
                <td className="px-6 py-3 text-ink/60 dark:text-parchment/60">{u.email}</td>
                <td className="px-6 py-3"><Badge>{u.role}</Badge></td>
                <td className="px-6 py-3">
                  <Badge tone={u.isActive ? "forest" : "clay"}>{u.isActive ? "Active" : "Suspended"}</Badge>
                </td>
                <td className="px-6 py-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleActive.mutate({ userId: u.id, isActive: !u.isActive })}
                  >
                    {u.isActive ? "Suspend" : "Reactivate"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
