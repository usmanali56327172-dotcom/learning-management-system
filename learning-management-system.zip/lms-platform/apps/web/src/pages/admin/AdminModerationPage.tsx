import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { PageSpinner } from "@/components/ui/Spinner";
import { Modal } from "@/components/ui/Modal";
import { adminApi } from "@/api/misc";

export function AdminModerationPage() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["moderation-queue"], queryFn: adminApi.moderationQueue });
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [reason, setReason] = useState("");

  const approve = useMutation({
    mutationFn: (courseId: string) => adminApi.approveCourse(courseId),
    onSuccess: () => {
      toast.success("Course approved and published");
      queryClient.invalidateQueries({ queryKey: ["moderation-queue"] });
    },
  });

  const reject = useMutation({
    mutationFn: () => adminApi.rejectCourse(rejectingId!, reason),
    onSuccess: () => {
      toast.success("Course rejected");
      setRejectingId(null);
      setReason("");
      queryClient.invalidateQueries({ queryKey: ["moderation-queue"] });
    },
  });

  const courses = data?.data || [];
  if (isLoading) return <PageSpinner />;

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Course moderation</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">Courses awaiting review before they go live.</p>

      <div className="mt-6 space-y-4">
        {courses.length === 0 && (
          <Card className="p-8 text-center text-sm text-ink/50 dark:text-parchment/50">Nothing pending review.</Card>
        )}
        {courses.map((c: any) => (
          <Card key={c.id} className="flex items-center justify-between p-5">
            <div>
              <h3 className="font-semibold">{c.title}</h3>
              <p className="text-sm text-ink/50 dark:text-parchment/50">
                By {c.instructor.firstName} {c.instructor.lastName} ({c.instructor.email})
              </p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="danger" onClick={() => setRejectingId(c.id)}>Reject</Button>
              <Button size="sm" onClick={() => approve.mutate(c.id)} isLoading={approve.isPending}>Approve</Button>
            </div>
          </Card>
        ))}
      </div>

      <Modal isOpen={!!rejectingId} onClose={() => setRejectingId(null)} title="Reject course">
        <p className="text-sm text-ink/60 dark:text-parchment/60">Explain what the instructor needs to fix.</p>
        <textarea
          rows={4}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="mt-3 w-full rounded-lg border border-ink/15 bg-white px-3.5 py-2.5 text-sm dark:border-night-border dark:bg-night-surface"
        />
        <Button className="mt-4 w-full" variant="danger" onClick={() => reject.mutate()} isLoading={reject.isPending} disabled={!reason}>
          Confirm rejection
        </Button>
      </Modal>
    </div>
  );
}
