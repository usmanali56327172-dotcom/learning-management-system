import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";
import { GraduationCap } from "lucide-react";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useRegister } from "@/hooks/useAuth";

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: "STUDENT" | "INSTRUCTOR";
}

export function RegisterPage() {
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormData>({
    defaultValues: { role: "STUDENT" },
  });
  const registerMutation = useRegister();
  const role = watch("role");

  return (
    <div className="flex min-h-screen items-center justify-center bg-parchment/30 px-4 py-10 dark:bg-night-bg">
      <div className="w-full max-w-sm">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2 font-display text-xl font-semibold">
          <GraduationCap className="h-6 w-6 text-gold" /> LMS
        </Link>
        <div className="rounded-2xl border border-ink/10 bg-white p-8 shadow-card dark:border-night-border dark:bg-night-surface">
          <h1 className="font-display text-2xl font-semibold">Create your account</h1>

          <div className="mt-4 grid grid-cols-2 gap-2 rounded-lg bg-ink/5 p-1 dark:bg-white/5">
            {(["STUDENT", "INSTRUCTOR"] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setValue("role", r)}
                className={`rounded-md py-2 text-sm font-medium transition-colors ${
                  role === r ? "bg-white shadow-sm dark:bg-night-bg" : "text-ink/50 dark:text-parchment/50"
                }`}
              >
                {r === "STUDENT" ? "I want to learn" : "I want to teach"}
              </button>
            ))}
          </div>

          <form className="mt-6 space-y-4" onSubmit={handleSubmit((data) => registerMutation.mutate(data))}>
            <div className="grid grid-cols-2 gap-3">
              <Input label="First name" error={errors.firstName?.message} {...register("firstName", { required: "Required" })} />
              <Input label="Last name" error={errors.lastName?.message} {...register("lastName", { required: "Required" })} />
            </div>
            <Input label="Email" type="email" error={errors.email?.message} {...register("email", { required: "Required" })} />
            <Input
              label="Password"
              type="password"
              hint="At least 8 characters"
              error={errors.password?.message}
              {...register("password", { required: "Required", minLength: { value: 8, message: "Minimum 8 characters" } })}
            />
            <Button type="submit" className="w-full" isLoading={registerMutation.isPending}>
              Create account
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-ink/60 dark:text-parchment/60">
            Already have an account?{" "}
            <Link to="/login" className="font-medium text-forest hover:underline dark:text-forest-light">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
