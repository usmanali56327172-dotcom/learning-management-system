import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/Card";
import { PageSpinner } from "@/components/ui/Spinner";
import { wishlistApi } from "@/api/misc";

export function WishlistPage() {
  const { data, isLoading } = useQuery({ queryKey: ["wishlist"], queryFn: wishlistApi.list });
  const items = data?.data || [];

  if (isLoading) return <PageSpinner />;

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Your wishlist</h1>
      {items.length === 0 ? (
        <Card className="mt-6 p-8 text-center text-sm text-ink/50 dark:text-parchment/50">
          Nothing saved yet. Tap the heart on any course to save it here.
        </Card>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {items.map((item: any) => (
            <Link key={item.id} to={`/courses/${item.course.slug}`}>
              <Card className="p-4">
                <h3 className="font-semibold">{item.course.title}</h3>
                <p className="mt-1 text-sm text-ink/50 dark:text-parchment/50">
                  {item.course.instructor.firstName} {item.course.instructor.lastName}
                </p>
                <p className="mt-2 font-display text-lg font-semibold">
                  {item.course.discountPrice ? `$${item.course.discountPrice}` : `$${item.course.price}`}
                </p>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
