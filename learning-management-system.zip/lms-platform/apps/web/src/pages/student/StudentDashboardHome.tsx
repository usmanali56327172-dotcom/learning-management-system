import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Clock } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { PageSpinner } from "@/components/ui/Spinner";
import { enrollmentsApi } from "@/api/enrollments";
import { useAuthStore } from "@/store/authStore";

export function StudentDashboardHome() {
  const user = useAuthStore((s) => s.user);
  const { data, isLoading } = useQuery({ queryKey: ["my-enrollments"], queryFn: enrollmentsApi.myEnrollments });
  const enrollments = data?.data || [];

  const inProgress = enrollments.filter((e: any) => e.status === "ACTIVE");
  const completed = enrollments.filter((e: any) => e.status === "COMPLETED");

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Welcome back, {user?.firstName}</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">Pick up where you left off.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">Enrolled</p>
          <p className="mt-1 font-display text-3xl font-semibold">{enrollments.length}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">In progress</p>
          <p className="mt-1 font-display text-3xl font-semibold">{inProgress.length}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs uppercase tracking-wide text-ink/50 dark:text-parchment/50">Completed</p>
          <p className="mt-1 font-display text-3xl font-semibold">{completed.length}</p>
        </Card>
      </div>

      <h2 className="mt-8 font-display text-lg font-semibold">Continue learning</h2>
      {isLoading ? (
        <PageSpinner />
      ) : enrollments.length === 0 ? (
        <Card className="mt-4 p-8 text-center text-sm text-ink/50 dark:text-parchment/50">
          You haven't enrolled in any courses yet. <Link to="/courses" className="text-forest underline dark:text-forest-light">Browse the catalog</Link>.
        </Card>
      ) : (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {enrollments.map((e: any) => (
            <Link key={e.id} to={`/courses/${e.course.slug}/learn`}>
              <Card className="relative overflow-hidden p-4">
                <div className="spine" />
                <div className="pl-3">
                  <h3 className="line-clamp-1 font-semibold">{e.course.title}</h3>
                  <p className="mt-0.5 text-xs text-ink/50 dark:text-parchment/50">
                    {e.course.instructor.firstName} {e.course.instructor.lastName}
                  </p>
                  <div className="mt-3 flex items-center gap-2">
                    <ProgressBar value={e.progressPct} className="flex-1" />
                    <span className="text-xs font-medium">{e.progressPct}%</span>
                  </div>
                  <p className="mt-2 flex items-center gap-1 text-xs text-ink/40 dark:text-parchment/40">
                    <Clock className="h-3 w-3" /> {e.course.totalLessons} lessons
                  </p>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
