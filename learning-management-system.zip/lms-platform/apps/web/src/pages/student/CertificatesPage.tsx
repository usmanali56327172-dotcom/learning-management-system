import { useQuery } from "@tanstack/react-query";
import { Award } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { PageSpinner } from "@/components/ui/Spinner";
import { certificatesApi } from "@/api/misc";

export function CertificatesPage() {
  const { data, isLoading } = useQuery({ queryKey: ["certificates"], queryFn: certificatesApi.mine });
  const certs = data?.data || [];

  if (isLoading) return <PageSpinner />;

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Your certificates</h1>
      {certs.length === 0 ? (
        <Card className="mt-6 p-8 text-center text-sm text-ink/50 dark:text-parchment/50">
          Complete a course to earn your first certificate.
        </Card>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {certs.map((cert: any) => (
            <Card key={cert.id} className="p-5">
              <Award className="h-8 w-8 text-gold" />
              <h3 className="mt-3 font-semibold">{cert.course.title}</h3>
              <p className="mt-1 font-mono text-xs text-ink/50 dark:text-parchment/50">{cert.serialNumber}</p>
              <p className="mt-1 text-xs text-ink/40 dark:text-parchment/40">
                Issued {new Date(cert.issuedAt).toLocaleDateString()}
              </p>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
