import { Link } from "react-router-dom";
import { CheckCircle2 } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/Button";

export function CheckoutSuccessPage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
        <CheckCircle2 className="h-16 w-16 text-forest dark:text-forest-light" />
        <h1 className="mt-4 font-display text-2xl font-semibold">Payment successful!</h1>
        <p className="mt-2 text-sm text-ink/60 dark:text-parchment/60">
          Your enrollment is confirmed. It may take a few seconds to appear on your dashboard.
        </p>
        <Link to="/dashboard" className="mt-6">
          <Button>Go to my dashboard</Button>
        </Link>
      </div>
    </div>
  );
}
