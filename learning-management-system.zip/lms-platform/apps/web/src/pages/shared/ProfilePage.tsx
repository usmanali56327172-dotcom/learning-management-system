import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";
import { apiClient } from "@/api/client";
import { useAuthStore } from "@/store/authStore";

interface FormData {
  firstName: string;
  lastName: string;
  headline: string;
  bio: string;
}

export function ProfilePage() {
  const user = useAuthStore((s) => s.user);
  const updateUser = useAuthStore((s) => s.updateUser);
  const { register, handleSubmit } = useForm<FormData>({
    defaultValues: { firstName: user?.firstName, lastName: user?.lastName },
  });

  const mutation = useMutation({
    mutationFn: (data: FormData) => apiClient.patch("/users/me", data).then((r) => r.data),
    onSuccess: (res) => {
      updateUser(res.data);
      toast.success("Profile updated");
    },
    onError: () => toast.error("Could not update profile"),
  });

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold">Profile settings</h1>

      <Card className="mt-6 p-6">
        <div className="flex items-center gap-4">
          <Avatar firstName={user?.firstName} lastName={user?.lastName} avatarUrl={user?.avatarUrl} size={64} />
          <div>
            <p className="font-semibold">{user?.firstName} {user?.lastName}</p>
            <p className="text-sm text-ink/50 dark:text-parchment/50">{user?.email}</p>
          </div>
        </div>

        <form className="mt-6 space-y-4" onSubmit={handleSubmit((data) => mutation.mutate(data))}>
          <div className="grid grid-cols-2 gap-3">
            <Input label="First name" {...register("firstName")} />
            <Input label="Last name" {...register("lastName")} />
          </div>
          <Input label="Headline" placeholder="e.g. Frontend developer & lifelong learner" {...register("headline")} />
          <div>
            <label className="mb-1.5 block text-sm font-medium">Bio</label>
            <textarea
              rows={4}
              className="w-full rounded-lg border border-ink/15 bg-white px-3.5 py-2.5 text-sm dark:border-night-border dark:bg-night-surface"
              {...register("bio")}
            />
          </div>
          <Button type="submit" isLoading={mutation.isPending}>Save changes</Button>
        </form>
      </Card>
    </div>
  );
}
