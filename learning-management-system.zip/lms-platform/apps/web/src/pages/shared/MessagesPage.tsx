import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Send, MessageSquare } from "lucide-react";
import clsx from "clsx";
import { Navbar } from "@/components/layout/Navbar";
import { Avatar } from "@/components/ui/Avatar";
import { PageSpinner } from "@/components/ui/Spinner";
import { messagingApi } from "@/api/messaging";
import { useAuthStore } from "@/store/authStore";
import { useSocket } from "@/hooks/useSocket";

export function MessagesPage() {
  const user = useAuthStore((s) => s.user);
  const queryClient = useQueryClient();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: conversationsData, isLoading } = useQuery({
    queryKey: ["conversations"],
    queryFn: messagingApi.listConversations,
  });
  const conversations = conversationsData?.data || [];
  const activeConversation = conversations.find((c: any) => c.id === activeId) || conversations[0];
  const activeConvId = activeConversation?.id;

  const { data: messagesData } = useQuery({
    queryKey: ["messages", activeConvId],
    queryFn: () => messagingApi.getMessages(activeConvId),
    enabled: !!activeConvId,
  });
  const messages = messagesData?.data || [];

  // Live updates: a new message anywhere refreshes the active thread and the sidebar previews.
  useSocket({
    "message:new": () => {
      queryClient.invalidateQueries({ queryKey: ["messages", activeConvId] });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
  });

  const sendMessage = useMutation({
    mutationFn: () => messagingApi.sendMessage(activeConvId, draft),
    onSuccess: () => {
      setDraft("");
      queryClient.invalidateQueries({ queryKey: ["messages", activeConvId] });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
  });

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages]);

  return (
    <div className="flex h-screen flex-col">
      <Navbar />
      <div className="flex flex-1 overflow-hidden">
        {/* Conversation list */}
        <aside className="w-full max-w-xs shrink-0 overflow-y-auto border-r border-ink/10 dark:border-night-border">
          <h1 className="p-4 font-display text-lg font-semibold">Messages</h1>
          {isLoading ? (
            <PageSpinner />
          ) : conversations.length === 0 ? (
            <p className="p-4 text-sm text-ink/50 dark:text-parchment/50">
              No conversations yet. Start one from a course or instructor page.
            </p>
          ) : (
            conversations.map((c: any) => {
              const other = c.participants.find((p: any) => p.user.id !== user?.id)?.user;
              const lastMessage = c.messages[0];
              return (
                <button
                  key={c.id}
                  onClick={() => setActiveId(c.id)}
                  className={clsx(
                    "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors",
                    (activeConvId === c.id) ? "bg-gold/10" : "hover:bg-ink/5 dark:hover:bg-white/5"
                  )}
                >
                  <Avatar firstName={other?.firstName} lastName={other?.lastName} avatarUrl={other?.avatarUrl} size={36} />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{other?.firstName} {other?.lastName}</p>
                    <p className="truncate text-xs text-ink/50 dark:text-parchment/50">
                      {lastMessage?.content || "No messages yet"}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </aside>

        {/* Active thread */}
        <main className="flex flex-1 flex-col">
          {!activeConversation ? (
            <div className="flex flex-1 flex-col items-center justify-center text-ink/40 dark:text-parchment/40">
              <MessageSquare className="mb-2 h-8 w-8" />
              Select a conversation to start chatting
            </div>
          ) : (
            <>
              <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-6">
                {messages.map((m: any) => {
                  const isMine = m.senderId === user?.id;
                  return (
                    <div key={m.id} className={clsx("flex", isMine ? "justify-end" : "justify-start")}>
                      <div
                        className={clsx(
                          "max-w-sm rounded-2xl px-4 py-2 text-sm",
                          isMine
                            ? "bg-ink text-paper dark:bg-gold dark:text-ink"
                            : "bg-parchment text-ink dark:bg-night-surface dark:text-parchment"
                        )}
                      >
                        {m.content}
                      </div>
                    </div>
                  );
                })}
              </div>
              <form
                className="flex items-center gap-2 border-t border-ink/10 p-4 dark:border-night-border"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (draft.trim()) sendMessage.mutate();
                }}
              >
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="Write a message..."
                  className="flex-1 rounded-full border border-ink/15 bg-white px-4 py-2 text-sm focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold dark:border-night-border dark:bg-night-surface"
                />
                <button
                  type="submit"
                  className="rounded-full bg-ink p-2.5 text-paper hover:bg-ink/90 dark:bg-gold dark:text-ink"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
