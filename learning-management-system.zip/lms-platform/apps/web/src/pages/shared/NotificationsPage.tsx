import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { PageSpinner } from "@/components/ui/Spinner";
import { notificationsApi } from "@/api/misc";

export function NotificationsPage() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["notifications"], queryFn: notificationsApi.list });

  const markAllRead = useMutation({
    mutationFn: notificationsApi.markAllRead,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  const notifications = data?.data || [];

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl font-semibold">Notifications</h1>
          <Button variant="outline" size="sm" onClick={() => markAllRead.mutate()}>Mark all read</Button>
        </div>

        {isLoading ? (
          <PageSpinner />
        ) : notifications.length === 0 ? (
          <Card className="mt-6 p-8 text-center text-sm text-ink/50 dark:text-parchment/50">
            <Bell className="mx-auto mb-2 h-6 w-6 text-ink/30" />
            You're all caught up.
          </Card>
        ) : (
          <div className="mt-6 space-y-2">
            {notifications.map((n: any) => (
              <Card key={n.id} className={`p-4 ${!n.isRead ? "border-gold/40 bg-gold/5" : ""}`}>
                <p className="font-medium">{n.title}</p>
                <p className="mt-0.5 text-sm text-ink/60 dark:text-parchment/60">{n.message}</p>
                <p className="mt-1 text-xs text-ink/40 dark:text-parchment/40">{new Date(n.createdAt).toLocaleString()}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
