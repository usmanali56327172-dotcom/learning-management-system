import { useSearchParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card } from "@/components/ui/Card";
import { PageSpinner } from "@/components/ui/Spinner";
import { searchApi } from "@/api/misc";

export function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";
  const { data, isLoading } = useQuery({ queryKey: ["search", q], queryFn: () => searchApi.search(q), enabled: !!q });
  const results = data?.data;

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <h1 className="font-display text-2xl font-semibold">Search results for "{q}"</h1>

        {isLoading ? (
          <PageSpinner />
        ) : (
          <div className="mt-6 space-y-8">
            <div>
              <h2 className="font-semibold">Courses</h2>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {results?.courses?.map((c: any) => (
                  <Link key={c.id} to={`/courses/${c.slug}`}>
                    <Card className="p-4"><p className="font-medium">{c.title}</p></Card>
                  </Link>
                ))}
                {results?.courses?.length === 0 && <p className="text-sm text-ink/50 dark:text-parchment/50">No courses found.</p>}
              </div>
            </div>
            <div>
              <h2 className="font-semibold">Instructors</h2>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {results?.instructors?.map((i: any) => (
                  <Card key={i.id} className="p-4">
                    <p className="font-medium">{i.firstName} {i.lastName}</p>
                    {i.headline && <p className="text-sm text-ink/50 dark:text-parchment/50">{i.headline}</p>}
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
