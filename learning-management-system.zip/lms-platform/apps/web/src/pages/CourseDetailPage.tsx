import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Star, Clock, BookOpen, Globe, Heart, PlayCircle, CheckCircle2, MessageSquare } from "lucide-react";
import toast from "react-hot-toast";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { PageSpinner } from "@/components/ui/Spinner";
import { coursesApi } from "@/api/courses";
import { enrollmentsApi } from "@/api/enrollments";
import { wishlistApi } from "@/api/misc";
import { paymentsApi } from "@/api/misc";
import { messagingApi } from "@/api/messaging";
import { useAuthStore } from "@/store/authStore";

export function CourseDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const user = useAuthStore((s) => s.user);
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [openSection, setOpenSection] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["course", slug],
    queryFn: () => coursesApi.getBySlug(slug!),
    enabled: !!slug,
  });

  const enrollFree = useMutation({
    mutationFn: (courseId: string) => enrollmentsApi.enrollFree(courseId),
    onSuccess: () => {
      toast.success("You're enrolled! Head to your dashboard to start learning.");
      queryClient.invalidateQueries({ queryKey: ["course", slug] });
    },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Could not enroll"),
  });

  const checkout = useMutation({
    mutationFn: (courseId: string) => paymentsApi.checkout(courseId),
    onSuccess: (res) => {
      window.location.href = res.data.checkoutUrl;
    },
    onError: (err: any) => toast.error(err?.response?.data?.message || "Checkout failed"),
  });

  const wishlist = useMutation({
    mutationFn: (courseId: string) => wishlistApi.toggle(courseId),
    onSuccess: (res) => toast.success(res.data.wishlisted ? "Added to wishlist" : "Removed from wishlist"),
  });

  const messageInstructor = useMutation({
    mutationFn: (instructorId: string) => messagingApi.startConversation(instructorId),
    onSuccess: () => navigate("/messages"),
    onError: () => toast.error("Could not start conversation"),
  });

  if (isLoading) return <PageSpinner />;
  const course = data?.data;
  if (!course) return null;

  const isFree = Number(course.price) === 0;

  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="border-b border-ink/10 bg-ink py-14 text-paper dark:border-night-border">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
          <div className="lg:col-span-2">
            <Badge tone="gold">{course.category?.name || "General"}</Badge>
            <h1 className="mt-3 font-display text-3xl font-semibold leading-tight sm:text-4xl">{course.title}</h1>
            {course.subtitle && <p className="mt-3 text-lg text-paper/70">{course.subtitle}</p>}
            <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-paper/70">
              <span className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-gold text-gold" /> {course.averageRating?.toFixed(1) || "New"} ({course.reviewCount} reviews)
              </span>
              <span>{course.enrollmentCount} students enrolled</span>
              <span>By {course.instructor?.firstName} {course.instructor?.lastName}</span>
            </div>
            <div className="mt-2 flex items-center gap-4 text-sm text-paper/60">
              <span className="flex items-center gap-1"><Globe className="h-4 w-4" /> {course.language}</span>
              <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {Math.round((course.totalDuration || 0) / 60)} min</span>
              <span className="flex items-center gap-1"><BookOpen className="h-4 w-4" /> {course.totalLessons} lessons</span>
            </div>
          </div>

          <Card className="h-fit p-5">
            {course.thumbnailUrl && (
              <img src={course.thumbnailUrl} alt={course.title} className="mb-4 aspect-video w-full rounded-lg object-cover" />
            )}
            <div className="flex items-baseline gap-2">
              {course.discountPrice ? (
                <>
                  <span className="font-display text-3xl font-semibold">${course.discountPrice}</span>
                  <span className="text-ink/40 line-through dark:text-parchment/40">${course.price}</span>
                </>
              ) : (
                <span className="font-display text-3xl font-semibold">{isFree ? "Free" : `$${course.price}`}</span>
              )}
            </div>

            {user ? (
              <div className="mt-4 space-y-2">
                <Button
                  className="w-full"
                  size="lg"
                  isLoading={enrollFree.isPending || checkout.isPending}
                  onClick={() => (isFree ? enrollFree.mutate(course.id) : checkout.mutate(course.id))}
                >
                  {isFree ? "Enroll for free" : "Buy now"}
                </Button>
                <Button variant="outline" className="w-full" onClick={() => wishlist.mutate(course.id)}>
                  <Heart className="h-4 w-4" /> Add to wishlist
                </Button>
              </div>
            ) : (
              <Button className="mt-4 w-full" size="lg" onClick={() => (window.location.href = "/login")}>
                Sign in to enroll
              </Button>
            )}

            {course.requirements?.length > 0 && (
              <div className="mt-6">
                <h4 className="text-sm font-semibold">Requirements</h4>
                <ul className="mt-2 space-y-1 text-sm text-ink/60 dark:text-parchment/60">
                  {course.requirements.map((r: string) => <li key={r}>• {r}</li>)}
                </ul>
              </div>
            )}
          </Card>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            {course.whatYouWillLearn?.length > 0 && (
              <Card className="p-6">
                <h2 className="font-display text-xl font-semibold">What you'll learn</h2>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  {course.whatYouWillLearn.map((w: string) => (
                    <div key={w} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-forest dark:text-forest-light" />
                      {w}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            <div className="mt-8">
              <h2 className="font-display text-xl font-semibold">Course content</h2>
              <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">
                {course.sections?.length || 0} sections · {course.totalLessons} lessons
              </p>
              <div className="mt-4 divide-y divide-ink/10 overflow-hidden rounded-xl border border-ink/10 dark:divide-night-border dark:border-night-border">
                {course.sections?.map((section: any) => (
                  <div key={section.id}>
                    <button
                      className="flex w-full items-center justify-between bg-parchment/40 px-4 py-3 text-left text-sm font-semibold dark:bg-night-surface/60"
                      onClick={() => setOpenSection(openSection === section.id ? null : section.id)}
                    >
                      {section.title}
                      <span className="text-xs font-normal text-ink/50 dark:text-parchment/50">{section.lessons.length} lessons</span>
                    </button>
                    {openSection === section.id && (
                      <div className="divide-y divide-ink/5 dark:divide-night-border">
                        {section.lessons.map((lesson: any) => (
                          <div key={lesson.id} className="flex items-center gap-2 px-4 py-2.5 text-sm">
                            <PlayCircle className="h-4 w-4 text-ink/40 dark:text-parchment/40" />
                            {lesson.title}
                            {lesson.isPreview && <Badge tone="gold" className="ml-auto">Preview</Badge>}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <h2 className="font-display text-xl font-semibold">Student reviews</h2>
              <div className="mt-4 space-y-4">
                {course.reviews?.length === 0 && <p className="text-sm text-ink/50 dark:text-parchment/50">No reviews yet.</p>}
                {course.reviews?.map((review: any) => (
                  <Card key={review.id} className="p-4">
                    <div className="flex items-center gap-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className={`h-3.5 w-3.5 ${i < review.rating ? "fill-gold text-gold" : "text-ink/20"}`} />
                      ))}
                      <span className="text-sm font-medium">{review.user.firstName} {review.user.lastName}</span>
                    </div>
                    {review.comment && <p className="mt-2 text-sm text-ink/70 dark:text-parchment/70">{review.comment}</p>}
                  </Card>
                ))}
              </div>
            </div>
          </div>

          <div>
            <Card className="p-6">
              <h3 className="font-semibold">About the instructor</h3>
              <p className="mt-2 font-display text-lg font-semibold">{course.instructor?.firstName} {course.instructor?.lastName}</p>
              {course.instructor?.headline && <p className="text-sm text-ink/60 dark:text-parchment/60">{course.instructor.headline}</p>}
              {user && user.id !== course.instructor?.id && (
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-4 w-full"
                  isLoading={messageInstructor.isPending}
                  onClick={() => messageInstructor.mutate(course.instructor.id)}
                >
                  <MessageSquare className="h-4 w-4" /> Message instructor
                </Button>
              )}
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
