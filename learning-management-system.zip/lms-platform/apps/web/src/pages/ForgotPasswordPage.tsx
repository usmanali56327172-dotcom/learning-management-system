import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { authApi } from "@/api/auth";

export function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const mutation = useMutation({
    mutationFn: () => authApi.forgotPassword(email),
    onSuccess: () => setSent(true),
  });

  return (
    <div className="flex min-h-screen items-center justify-center bg-parchment/30 px-4 dark:bg-night-bg">
      <div className="w-full max-w-sm rounded-2xl border border-ink/10 bg-white p-8 shadow-card dark:border-night-border dark:bg-night-surface">
        <h1 className="font-display text-2xl font-semibold">Reset your password</h1>
        {sent ? (
          <p className="mt-4 text-sm text-ink/60 dark:text-parchment/60">
            If an account exists for that email, a reset link is on its way.
          </p>
        ) : (
          <form
            className="mt-6 space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              mutation.mutate();
            }}
          >
            <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <Button type="submit" className="w-full" isLoading={mutation.isPending}>Send reset link</Button>
          </form>
        )}
        <p className="mt-6 text-center text-sm">
          <Link to="/login" className="text-forest hover:underline dark:text-forest-light">Back to sign in</Link>
        </p>
      </div>
    </div>
  );
}
