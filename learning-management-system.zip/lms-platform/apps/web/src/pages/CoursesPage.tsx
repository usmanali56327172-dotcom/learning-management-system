import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useSearchParams } from "react-router-dom";
import { Star, Clock, Users } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { PageSpinner } from "@/components/ui/Spinner";
import { coursesApi } from "@/api/courses";

const SORT_OPTIONS = [
  { value: "newest", label: "Newest" },
  { value: "popular", label: "Most popular" },
  { value: "rating", label: "Top rated" },
  { value: "price_asc", label: "Price: Low to high" },
  { value: "price_desc", label: "Price: High to low" },
];

export function CoursesPage() {
  const [searchParams] = useSearchParams();
  const [sort, setSort] = useState("newest");
  const search = searchParams.get("search") || "";

  const { data, isLoading } = useQuery({
    queryKey: ["courses", { search, sort }],
    queryFn: () => coursesApi.list({ search, sort, limit: 12 }),
  });

  const courses = data?.data || [];

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold">Explore courses</h1>
            <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">
              {data?.meta?.total ?? 0} published courses{search ? ` matching "${search}"` : ""}
            </p>
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-lg border border-ink/15 bg-white px-3 py-2 text-sm dark:border-night-border dark:bg-night-surface"
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>

        {isLoading ? (
          <PageSpinner />
        ) : courses.length === 0 ? (
          <div className="mt-16 text-center text-ink/50 dark:text-parchment/50">
            No courses found yet. Check back soon, or try a different search.
          </div>
        ) : (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {courses.map((course: any) => (
              <Link key={course.id} to={`/courses/${course.slug}`}>
                <Card className="group relative h-full overflow-hidden p-0 transition-shadow hover:shadow-card-hover">
                  <div className="spine" />
                  <div className="aspect-video w-full bg-parchment dark:bg-night-bg">
                    {course.thumbnailUrl && (
                      <img src={course.thumbnailUrl} alt={course.title} className="h-full w-full object-cover" />
                    )}
                  </div>
                  <div className="p-4 pl-5">
                    <Badge tone="forest">{course.level?.replace("_", " ") || "All levels"}</Badge>
                    <h3 className="mt-2 line-clamp-2 font-display text-lg font-semibold leading-snug group-hover:text-forest dark:group-hover:text-forest-light">
                      {course.title}
                    </h3>
                    <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">
                      {course.instructor?.firstName} {course.instructor?.lastName}
                    </p>
                    <div className="mt-3 flex items-center gap-4 text-xs text-ink/50 dark:text-parchment/50">
                      <span className="flex items-center gap-1">
                        <Star className="h-3.5 w-3.5 fill-gold text-gold" /> {course.averageRating?.toFixed(1) || "New"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-3.5 w-3.5" /> {course.enrollmentCount ?? 0}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" /> {Math.round((course.totalDuration || 0) / 60)}m
                      </span>
                    </div>
                    <div className="mt-3 flex items-baseline gap-2">
                      {course.discountPrice ? (
                        <>
                          <span className="font-display text-lg font-semibold">${course.discountPrice}</span>
                          <span className="text-sm text-ink/40 line-through dark:text-parchment/40">${course.price}</span>
                        </>
                      ) : (
                        <span className="font-display text-lg font-semibold">
                          {Number(course.price) === 0 ? "Free" : `$${course.price}`}
                        </span>
                      )}
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
