import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen, Award, Users, BarChart3, Star } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

const stats = [
  { label: "Courses published", value: "12,400+" },
  { label: "Learners enrolled", value: "2.1M" },
  { label: "Certificates issued", value: "540K" },
  { label: "Instructor payout", value: "$18M" },
];

const paths = [
  {
    step: "I",
    title: "Enroll",
    body: "Find a course by subject, level, or instructor — preview any lesson before you commit.",
  },
  {
    step: "II",
    title: "Study",
    body: "Track lessons, bookmark key moments, and pick up exactly where you left off on any device.",
  },
  {
    step: "III",
    title: "Prove it",
    body: "Pass quizzes and assignments, then earn a verifiable certificate with a public serial number.",
  },
];

const featureGrid = [
  { icon: BookOpen, title: "Structured curriculum", body: "Sections, lessons, quizzes, and assignments — organized the way a real syllabus is." },
  { icon: BarChart3, title: "Real analytics", body: "Instructors see enrollment trends and revenue; admins see platform-wide health at a glance." },
  { icon: Users, title: "Direct messaging", body: "Ask your instructor a question and hear back — no forum thread required." },
  { icon: Award, title: "Verifiable certificates", body: "Every certificate has a serial number anyone can verify, no login needed." },
];

export function LandingPage() {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-ink/10 dark:border-night-border">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-xs font-medium uppercase tracking-wide text-gold-dark dark:text-gold-light">
              Now enrolling instructors
            </span>
            <h1 className="font-display text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              A syllabus, <span className="italic text-forest dark:text-forest-light">not</span> a feed.
            </h1>
            <p className="mt-6 max-w-lg text-lg text-ink/70 dark:text-parchment/70">
              Learning Management System is built around the shape of real courses — sections, lessons, quizzes, graded
              assignments, and a certificate at the end. No infinite scroll, just a curriculum you can finish.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link to="/courses">
                <Button size="lg">
                  Browse the catalog <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/register">
                <Button size="lg" variant="outline">Teach with us</Button>
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="relative"
          >
            <Card className="relative overflow-hidden p-6">
              <div className="spine" />
              <div className="pl-4">
                <p className="font-mono text-xs uppercase tracking-wider text-ink/40 dark:text-parchment/40">Currently learning</p>
                <h3 className="mt-1 font-display text-xl font-semibold">The Complete React Developer Course</h3>
                <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">Section 3 of 8 · Building Custom Hooks</p>
                <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-ink/10 dark:bg-white/10">
                  <div className="h-full w-[62%] rounded-full bg-gradient-to-r from-forest to-gold" />
                </div>
                <p className="mt-2 text-xs text-ink/50 dark:text-parchment/50">62% complete · 3h 20m remaining</p>
              </div>
            </Card>
            <Card className="absolute -bottom-6 -left-6 hidden w-48 rotate-[-4deg] p-4 sm:block">
              <div className="flex items-center gap-2">
                <Star className="h-4 w-4 fill-gold text-gold" />
                <Star className="h-4 w-4 fill-gold text-gold" />
                <Star className="h-4 w-4 fill-gold text-gold" />
                <Star className="h-4 w-4 fill-gold text-gold" />
                <Star className="h-4 w-4 fill-gold text-gold" />
              </div>
              <p className="mt-1 text-xs text-ink/60 dark:text-parchment/60">"Finally, a course platform that feels like a real classroom."</p>
            </Card>
          </motion.div>
        </div>

        <div className="border-t border-ink/10 bg-parchment/50 py-8 dark:border-night-border dark:bg-night-surface/50">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 sm:px-6 md:grid-cols-4 lg:px-8">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <p className="font-display text-2xl font-semibold sm:text-3xl">{s.value}</p>
                <p className="mt-1 text-xs text-ink/50 dark:text-parchment/50">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works — a real sequence, so numbering is earned */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <h2 className="font-display text-3xl font-semibold">How a course actually works here</h2>
        <p className="mt-2 max-w-xl text-ink/60 dark:text-parchment/60">Three steps, in order — because that's the order they happen in.</p>
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {paths.map((p) => (
            <div key={p.step} className="relative border-t-2 border-ink/10 pt-6 dark:border-night-border">
              <span className="font-display text-4xl text-gold/50">{p.step}</span>
              <h3 className="mt-3 text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-sm text-ink/60 dark:text-parchment/60">{p.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Feature grid */}
      <section className="border-y border-ink/10 bg-parchment/40 py-20 dark:border-night-border dark:bg-night-surface/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-display text-3xl font-semibold">Everything a course needs, nothing it doesn't</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {featureGrid.map((f) => (
              <Card key={f.title} className="p-6">
                <f.icon className="h-6 w-6 text-forest dark:text-forest-light" />
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-ink/60 dark:text-parchment/60">{f.body}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-20 text-center sm:px-6 lg:px-8">
        <h2 className="font-display text-3xl font-semibold sm:text-4xl">Your syllabus is waiting.</h2>
        <p className="mx-auto mt-3 max-w-md text-ink/60 dark:text-parchment/60">
          Whether you're here to learn or to teach, the first course is one click away.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link to="/register"><Button size="lg">Create your free account</Button></Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
