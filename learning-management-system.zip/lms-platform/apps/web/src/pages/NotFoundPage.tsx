import { Link } from "react-router-dom";
import { Button } from "@/components/ui/Button";

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center text-center">
      <p className="font-display text-6xl font-semibold text-gold">404</p>
      <h1 className="mt-3 text-xl font-semibold">This page isn't on the syllabus.</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">Let's get you back to something useful.</p>
      <Link to="/" className="mt-6"><Button>Back to home</Button></Link>
    </div>
  );
}
