import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { PageSpinner } from "@/components/ui/Spinner";
import { quizzesApi } from "@/api/learning";

export function QuizBlock({ lessonId, onPassed }: { lessonId: string; onPassed: () => void }) {
  const queryClient = useQueryClient();
  const [answers, setAnswers] = useState<Record<string, number>>({});

  const { data, isLoading } = useQuery({
    queryKey: ["quiz", lessonId],
    queryFn: () => quizzesApi.get(lessonId),
  });
  const quiz = data?.data;

  const { data: attemptsData } = useQuery({
    queryKey: ["quiz-attempts", quiz?.id],
    queryFn: () => quizzesApi.myAttempts(quiz.id),
    enabled: !!quiz?.id,
  });
  const attempts = attemptsData?.data || [];
  const latestAttempt = attempts[0];

  const submit = useMutation({
    mutationFn: () => quizzesApi.submitAttempt(quiz.id, answers),
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["quiz-attempts", quiz.id] });
      if (res.data.passed) onPassed();
    },
  });

  if (isLoading) return <PageSpinner />;
  if (!quiz) return <p className="text-sm text-ink/50 dark:text-parchment/50">No quiz found for this lesson.</p>;

  const allAnswered = quiz.questions.every((q: any) => answers[q.id] !== undefined);

  return (
    <Card className="p-6">
      <h3 className="font-display text-lg font-semibold">{quiz.title}</h3>
      <p className="mt-1 text-sm text-ink/50 dark:text-parchment/50">
        Passing score: {quiz.passingScore}% · {quiz.questions.length} questions
      </p>

      {latestAttempt && (
        <div
          className={`mt-4 flex items-center gap-2 rounded-lg p-3 text-sm ${
            latestAttempt.passed ? "bg-forest/10 text-forest dark:text-forest-light" : "bg-clay/10 text-clay"
          }`}
        >
          {latestAttempt.passed ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
          Your last attempt scored {latestAttempt.score}% — {latestAttempt.passed ? "passed!" : "try again below."}
        </div>
      )}

      <div className="mt-5 space-y-5">
        {quiz.questions.map((q: any, idx: number) => (
          <div key={q.id}>
            <p className="text-sm font-medium">{idx + 1}. {q.question}</p>
            <div className="mt-2 space-y-1.5">
              {q.options.map((opt: string, optIdx: number) => (
                <label
                  key={optIdx}
                  className="flex cursor-pointer items-center gap-2 rounded-lg border border-ink/10 px-3 py-2 text-sm hover:bg-ink/5 dark:border-night-border dark:hover:bg-white/5"
                >
                  <input
                    type="radio"
                    name={q.id}
                    checked={answers[q.id] === optIdx}
                    onChange={() => setAnswers({ ...answers, [q.id]: optIdx })}
                  />
                  {opt}
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>

      <Button
        className="mt-6"
        disabled={!allAnswered}
        isLoading={submit.isPending}
        onClick={() => submit.mutate()}
      >
        Submit quiz
      </Button>
    </Card>
  );
}
