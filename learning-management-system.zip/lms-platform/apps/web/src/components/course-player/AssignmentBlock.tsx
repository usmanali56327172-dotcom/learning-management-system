import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { assignmentsApi } from "@/api/learning";

export function AssignmentBlock({
  assignmentId,
  title,
  instructions,
  maxScore,
}: {
  assignmentId: string;
  title: string;
  instructions: string;
  maxScore: number;
}) {
  const [contentUrl, setContentUrl] = useState("");
  const [notes, setNotes] = useState("");

  const submit = useMutation({
    mutationFn: () => assignmentsApi.submit(assignmentId, contentUrl, notes),
    onSuccess: () => toast.success("Assignment submitted — your instructor will grade it soon."),
    onError: () => toast.error("Could not submit assignment"),
  });

  return (
    <Card className="p-6">
      <h3 className="font-display text-lg font-semibold">{title}</h3>
      <p className="mt-1 text-xs uppercase tracking-wide text-ink/40 dark:text-parchment/40">
        Graded out of {maxScore} points
      </p>
      <p className="mt-3 whitespace-pre-wrap text-sm text-ink/70 dark:text-parchment/70">{instructions}</p>

      <div className="mt-5 space-y-3">
        <Input
          label="Link to your work"
          placeholder="https://github.com/you/project or a Google Drive link"
          value={contentUrl}
          onChange={(e) => setContentUrl(e.target.value)}
        />
        <div>
          <label className="mb-1.5 block text-sm font-medium">Notes for your instructor (optional)</label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full rounded-lg border border-ink/15 bg-white px-3.5 py-2.5 text-sm dark:border-night-border dark:bg-night-surface"
          />
        </div>
        <Button isLoading={submit.isPending} disabled={!contentUrl} onClick={() => submit.mutate()}>
          Submit assignment
        </Button>
      </div>
    </Card>
  );
}
