export function ProgressBar({ value, className = "" }: { value: number; className?: string }) {
  return (
    <div className={`h-1.5 w-full overflow-hidden rounded-full bg-ink/10 dark:bg-white/10 ${className}`}>
      <div
        className="h-full rounded-full bg-gradient-to-r from-forest to-gold transition-all duration-500"
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}
