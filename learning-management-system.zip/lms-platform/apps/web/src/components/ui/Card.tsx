import { HTMLAttributes } from "react";
import clsx from "clsx";

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={clsx(
        "rounded-xl border border-ink/10 bg-white shadow-card dark:border-night-border dark:bg-night-surface",
        className
      )}
      {...props}
    />
  );
}
