import { InputHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, hint, id, ...props }, ref) => {
    const inputId = id || props.name;
    return (
      <div className="w-full">
        {label && (
          <label htmlFor={inputId} className="mb-1.5 block text-sm font-medium text-ink dark:text-parchment">
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={clsx(
            "w-full rounded-lg border bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink/40 transition-colors",
            "dark:bg-night-surface dark:text-parchment dark:placeholder:text-parchment/40",
            error
              ? "border-clay focus:border-clay"
              : "border-ink/15 focus:border-gold dark:border-night-border dark:focus:border-gold",
            "focus:outline-none focus:ring-1 focus:ring-gold",
            className
          )}
          {...props}
        />
        {error && <p className="mt-1 text-xs text-clay">{error}</p>}
        {hint && !error && <p className="mt-1 text-xs text-ink/50 dark:text-parchment/50">{hint}</p>}
      </div>
    );
  }
);
Input.displayName = "Input";
