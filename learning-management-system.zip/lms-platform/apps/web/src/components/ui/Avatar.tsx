export function Avatar({
  firstName,
  lastName,
  avatarUrl,
  size = 40,
}: {
  firstName?: string;
  lastName?: string;
  avatarUrl?: string | null;
  size?: number;
}) {
  const initials = `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  if (avatarUrl) {
    return (
      <img
        src={avatarUrl}
        alt={`${firstName} ${lastName}`}
        style={{ width: size, height: size }}
        className="rounded-full object-cover"
      />
    );
  }
  return (
    <div
      style={{ width: size, height: size }}
      className="flex items-center justify-center rounded-full bg-forest font-display text-sm font-semibold text-paper"
    >
      {initials || "?"}
    </div>
  );
}
