import { HTMLAttributes } from "react";
import clsx from "clsx";

type Tone = "neutral" | "gold" | "forest" | "clay";

const toneStyles: Record<Tone, string> = {
  neutral: "bg-ink/8 text-ink dark:bg-white/10 dark:text-parchment",
  gold: "bg-gold/15 text-gold-dark dark:text-gold-light",
  forest: "bg-forest/10 text-forest dark:text-forest-light",
  clay: "bg-clay/10 text-clay",
};

export function Badge({ tone = "neutral", className, ...props }: HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={clsx(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        toneStyles[tone],
        className
      )}
      {...props}
    />
  );
}
