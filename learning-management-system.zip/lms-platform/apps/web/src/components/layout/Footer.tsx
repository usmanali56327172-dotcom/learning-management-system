import { Link } from "react-router-dom";
import { GraduationCap } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-ink/10 bg-parchment/40 py-12 dark:border-night-border dark:bg-night-surface/40">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 sm:px-6 md:grid-cols-4 lg:px-8">
        <div className="col-span-2 md:col-span-1">
          <div className="mb-3 flex items-center gap-2 font-display text-lg font-semibold">
            <GraduationCap className="h-5 w-5 text-gold" /> LMS
          </div>
          <p className="text-sm text-ink/60 dark:text-parchment/60">
            A modern place to teach and learn, one course at a time.
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Learn</h4>
          <ul className="space-y-2 text-sm text-ink/60 dark:text-parchment/60">
            <li><Link to="/courses">Browse courses</Link></li>
            <li><Link to="/certificates">Certificates</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Teach</h4>
          <ul className="space-y-2 text-sm text-ink/60 dark:text-parchment/60">
            <li><Link to="/instructor">Instructor dashboard</Link></li>
            <li><Link to="/register">Become an instructor</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Company</h4>
          <ul className="space-y-2 text-sm text-ink/60 dark:text-parchment/60">
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </div>
      </div>
      <p className="mt-10 text-center text-xs text-ink/40 dark:text-parchment/40">
        © {new Date().getFullYear()} Learning Management System. Built as a portfolio project.
      </p>
    </footer>
  );
}
