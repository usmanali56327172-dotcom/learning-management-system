import { NavLink, Outlet } from "react-router-dom";
import clsx from "clsx";
import { LucideIcon } from "lucide-react";
import { Navbar } from "./Navbar";

export interface DashboardNavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  end?: boolean;
}

export function DashboardLayout({ navItems, title }: { navItems: DashboardNavItem[]; title: string }) {
  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="mx-auto flex max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:px-8">
        <aside className="hidden w-56 shrink-0 md:block">
          <h2 className="mb-4 px-2 font-display text-lg font-semibold">{title}</h2>
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  clsx(
                    "flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-ink text-paper dark:bg-gold dark:text-ink"
                      : "text-ink/70 hover:bg-ink/5 dark:text-parchment/70 dark:hover:bg-white/5"
                  )
                }
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </NavLink>
            ))}
          </nav>
        </aside>
        <main className="min-w-0 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
