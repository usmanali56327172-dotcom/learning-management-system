import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, Moon, Sun, Bell, MessageSquare, Menu, X, GraduationCap } from "lucide-react";
import { useThemeStore } from "@/store/themeStore";
import { useAuthStore } from "@/store/authStore";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";

export function Navbar() {
  const { isDark, toggle } = useThemeStore();
  const { user, clearSession } = useAuthStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const dashboardPath =
    user?.role === "ADMIN" ? "/admin" : user?.role === "INSTRUCTOR" ? "/instructor" : "/dashboard";

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  }

  return (
    <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/90 backdrop-blur dark:border-night-border dark:bg-night-bg/90">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-semibold">
          <GraduationCap className="h-6 w-6 text-gold" />
          LMS
        </Link>

        <form onSubmit={handleSearch} className="relative hidden flex-1 max-w-md md:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40 dark:text-parchment/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search courses, topics, instructors..."
            className="w-full rounded-full border border-ink/15 bg-white py-2 pl-9 pr-4 text-sm focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold dark:border-night-border dark:bg-night-surface"
          />
        </form>

        <nav className="ml-auto hidden items-center gap-1 md:flex">
          <Link to="/courses" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-ink/5 dark:hover:bg-white/5">
            Explore
          </Link>

          <button
            onClick={toggle}
            aria-label="Toggle dark mode"
            className="rounded-lg p-2 hover:bg-ink/5 dark:hover:bg-white/5"
          >
            {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>

          {user ? (
            <>
              <Link to="/messages" className="rounded-lg p-2 hover:bg-ink/5 dark:hover:bg-white/5">
                <MessageSquare className="h-5 w-5" />
              </Link>
              <Link to="/notifications" className="rounded-lg p-2 hover:bg-ink/5 dark:hover:bg-white/5">
                <Bell className="h-5 w-5" />
              </Link>
              <Link to={dashboardPath} className="ml-1 flex items-center gap-2 rounded-full p-1 hover:bg-ink/5 dark:hover:bg-white/5">
                <Avatar firstName={user.firstName} lastName={user.lastName} avatarUrl={user.avatarUrl} size={32} />
              </Link>
              <Button variant="ghost" size="sm" onClick={() => { clearSession(); navigate("/"); }}>
                Sign out
              </Button>
            </>
          ) : (
            <>
              <Link to="/login">
                <Button variant="ghost" size="sm">Sign in</Button>
              </Link>
              <Link to="/register">
                <Button variant="primary" size="sm">Get started</Button>
              </Link>
            </>
          )}
        </nav>

        <button className="ml-auto md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-ink/10 px-4 py-4 md:hidden dark:border-night-border">
          <form onSubmit={handleSearch} className="mb-3">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search courses..."
              className="w-full rounded-full border border-ink/15 bg-white px-4 py-2 text-sm dark:bg-night-surface dark:border-night-border"
            />
          </form>
          <div className="flex flex-col gap-2">
            <Link to="/courses" onClick={() => setMobileOpen(false)}>Explore courses</Link>
            {user ? (
              <>
                <Link to={dashboardPath} onClick={() => setMobileOpen(false)}>Dashboard</Link>
                <button className="text-left" onClick={() => { clearSession(); navigate("/"); }}>Sign out</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setMobileOpen(false)}>Sign in</Link>
                <Link to="/register" onClick={() => setMobileOpen(false)}>Get started</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
