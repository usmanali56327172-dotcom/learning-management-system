import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { assignmentAuthoringApi } from "@/api/learning";

export function AssignmentAuthorModal({
  isOpen,
  onClose,
  lessonId,
  onCreated,
}: {
  isOpen: boolean;
  onClose: () => void;
  lessonId: string;
  onCreated: () => void;
}) {
  const [title, setTitle] = useState("");
  const [instructions, setInstructions] = useState("");
  const [maxScore, setMaxScore] = useState(100);

  const create = useMutation({
    mutationFn: () => assignmentAuthoringApi.create(lessonId, { title, instructions, maxScore }),
    onSuccess: () => {
      toast.success("Assignment created");
      onCreated();
      onClose();
    },
    onError: () => toast.error("Could not create assignment"),
  });

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add assignment brief">
      <div className="space-y-4">
        <Input label="Assignment title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <div>
          <label className="mb-1.5 block text-sm font-medium">Instructions</label>
          <textarea
            rows={5}
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            placeholder="What should the student build or submit? Be specific about the deliverable and format."
            className="w-full rounded-lg border border-ink/15 bg-white px-3.5 py-2.5 text-sm dark:border-night-border dark:bg-night-surface"
          />
        </div>
        <Input label="Max score" type="number" value={maxScore} onChange={(e) => setMaxScore(Number(e.target.value))} />
      </div>
      <Button
        className="mt-4 w-full"
        disabled={!title.trim() || !instructions.trim()}
        isLoading={create.isPending}
        onClick={() => create.mutate()}
      >
        Save assignment
      </Button>
    </Modal>
  );
}
