import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { Plus, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { quizAuthoringApi } from "@/api/learning";

interface DraftQuestion {
  question: string;
  options: string[];
  correctOption: number;
}

const BLANK_QUESTION: DraftQuestion = { question: "", options: ["", ""], correctOption: 0 };

export function QuizAuthorModal({
  isOpen,
  onClose,
  lessonId,
  onCreated,
}: {
  isOpen: boolean;
  onClose: () => void;
  lessonId: string;
  onCreated: () => void;
}) {
  const [title, setTitle] = useState("");
  const [passingScore, setPassingScore] = useState(70);
  const [questions, setQuestions] = useState<DraftQuestion[]>([{ ...BLANK_QUESTION, options: ["", ""] }]);

  const create = useMutation({
    mutationFn: () => {
      const payload = {
        title,
        passingScore,
        questions: questions.map((q) => {
          const correctText = q.options[q.correctOption];
          const filteredOptions = q.options.filter((o) => o.trim() !== "");
          const remappedCorrectIndex = filteredOptions.indexOf(correctText);
          return { question: q.question, options: filteredOptions, correctOption: Math.max(remappedCorrectIndex, 0) };
        }),
      };
      return quizAuthoringApi.create(lessonId, payload);
    },
    onSuccess: () => {
      toast.success("Quiz created");
      onCreated();
      onClose();
    },
    onError: () => toast.error("Could not create quiz — check every question has at least 2 options"),
  });

  const updateQuestion = (idx: number, patch: Partial<DraftQuestion>) => {
    setQuestions((qs) => qs.map((q, i) => (i === idx ? { ...q, ...patch } : q)));
  };

  const isValid =
    title.trim() &&
    questions.length > 0 &&
    questions.every((q) => q.question.trim() && q.options.filter(Boolean).length >= 2);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add quiz questions">
      <div className="max-h-[65vh] space-y-4 overflow-y-auto pr-1">
        <Input label="Quiz title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Input
          label="Passing score (%)"
          type="number"
          value={passingScore}
          onChange={(e) => setPassingScore(Number(e.target.value))}
        />

        {questions.map((q, qIdx) => (
          <div key={qIdx} className="rounded-lg border border-ink/10 p-3 dark:border-night-border">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Question {qIdx + 1}</p>
              {questions.length > 1 && (
                <button onClick={() => setQuestions((qs) => qs.filter((_, i) => i !== qIdx))}>
                  <Trash2 className="h-4 w-4 text-clay" />
                </button>
              )}
            </div>
            <input
              placeholder="Question text"
              value={q.question}
              onChange={(e) => updateQuestion(qIdx, { question: e.target.value })}
              className="mt-2 w-full rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm dark:border-night-border dark:bg-night-surface"
            />
            <div className="mt-2 space-y-1.5">
              {q.options.map((opt, optIdx) => (
                <div key={optIdx} className="flex items-center gap-2">
                  <input
                    type="radio"
                    name={`correct-${qIdx}`}
                    checked={q.correctOption === optIdx}
                    onChange={() => updateQuestion(qIdx, { correctOption: optIdx })}
                  />
                  <input
                    placeholder={`Option ${optIdx + 1}`}
                    value={opt}
                    onChange={(e) => {
                      const options = [...q.options];
                      options[optIdx] = e.target.value;
                      updateQuestion(qIdx, { options });
                    }}
                    className="flex-1 rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm dark:border-night-border dark:bg-night-surface"
                  />
                </div>
              ))}
              <button
                type="button"
                className="text-xs text-forest hover:underline dark:text-forest-light"
                onClick={() => updateQuestion(qIdx, { options: [...q.options, ""] })}
              >
                + Add option
              </button>
            </div>
          </div>
        ))}

        <Button
          variant="outline"
          size="sm"
          onClick={() => setQuestions((qs) => [...qs, { ...BLANK_QUESTION, options: ["", ""] }])}
        >
          <Plus className="h-3.5 w-3.5" /> Add question
        </Button>
      </div>

      <Button className="mt-4 w-full" disabled={!isValid} isLoading={create.isPending} onClick={() => create.mutate()}>
        Save quiz
      </Button>
    </Modal>
  );
}
