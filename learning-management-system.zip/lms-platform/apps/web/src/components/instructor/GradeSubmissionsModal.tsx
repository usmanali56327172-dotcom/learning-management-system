import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { ExternalLink } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { PageSpinner } from "@/components/ui/Spinner";
import { Avatar } from "@/components/ui/Avatar";
import { assignmentGradingApi } from "@/api/learning";

export function GradeSubmissionsModal({
  isOpen,
  onClose,
  assignmentId,
  maxScore,
}: {
  isOpen: boolean;
  onClose: () => void;
  assignmentId: string;
  maxScore: number;
}) {
  const queryClient = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, { score: string; feedback: string }>>({});

  const { data, isLoading } = useQuery({
    queryKey: ["assignment-submissions", assignmentId],
    queryFn: () => assignmentGradingApi.listSubmissions(assignmentId),
    enabled: isOpen,
  });
  const submissions = data?.data || [];

  const grade = useMutation({
    mutationFn: ({ submissionId, score, feedback }: { submissionId: string; score: number; feedback?: string }) =>
      assignmentGradingApi.grade(submissionId, score, feedback),
    onSuccess: () => {
      toast.success("Grade submitted");
      queryClient.invalidateQueries({ queryKey: ["assignment-submissions", assignmentId] });
    },
    onError: () => toast.error("Could not save grade"),
  });

  const getDraft = (id: string) => drafts[id] || { score: "", feedback: "" };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Grade submissions">
      {isLoading ? (
        <PageSpinner />
      ) : submissions.length === 0 ? (
        <p className="text-sm text-ink/50 dark:text-parchment/50">No submissions yet.</p>
      ) : (
        <div className="max-h-[65vh] space-y-4 overflow-y-auto pr-1">
          {submissions.map((s: any) => (
            <div key={s.id} className="rounded-lg border border-ink/10 p-3 dark:border-night-border">
              <div className="flex items-center gap-2">
                <Avatar firstName={s.user.firstName} lastName={s.user.lastName} avatarUrl={s.user.avatarUrl} size={28} />
                <p className="text-sm font-medium">{s.user.firstName} {s.user.lastName}</p>
                <Badge tone={s.status === "GRADED" ? "forest" : "gold"} className="ml-auto">{s.status}</Badge>
              </div>
              <a
                href={s.contentUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-2 flex items-center gap-1 text-sm text-forest hover:underline dark:text-forest-light"
              >
                View submission <ExternalLink className="h-3.5 w-3.5" />
              </a>
              {s.notes && <p className="mt-1 text-sm text-ink/60 dark:text-parchment/60">"{s.notes}"</p>}

              {s.status === "GRADED" ? (
                <p className="mt-2 text-sm">
                  Score: <strong>{s.score}/{maxScore}</strong>
                  {s.feedback && <span className="ml-2 text-ink/60 dark:text-parchment/60">— {s.feedback}</span>}
                </p>
              ) : (
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <input
                    type="number"
                    max={maxScore}
                    min={0}
                    placeholder={`Score / ${maxScore}`}
                    value={getDraft(s.id).score}
                    onChange={(e) => setDrafts({ ...drafts, [s.id]: { ...getDraft(s.id), score: e.target.value } })}
                    className="w-28 rounded-lg border border-ink/15 bg-white px-2 py-1 text-sm dark:border-night-border dark:bg-night-surface"
                  />
                  <input
                    placeholder="Feedback (optional)"
                    value={getDraft(s.id).feedback}
                    onChange={(e) => setDrafts({ ...drafts, [s.id]: { ...getDraft(s.id), feedback: e.target.value } })}
                    className="flex-1 rounded-lg border border-ink/15 bg-white px-2 py-1 text-sm dark:border-night-border dark:bg-night-surface"
                  />
                  <Button
                    size="sm"
                    disabled={!getDraft(s.id).score}
                    isLoading={grade.isPending}
                    onClick={() =>
                      grade.mutate({
                        submissionId: s.id,
                        score: Number(getDraft(s.id).score),
                        feedback: getDraft(s.id).feedback || undefined,
                      })
                    }
                  >
                    Save grade
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
