import { useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import { LayoutDashboard, BookOpen, Heart, Award, User, BarChart3, ShieldCheck, Users, FileCheck } from "lucide-react";
import { useThemeStore } from "@/store/themeStore";

import { LandingPage } from "@/pages/LandingPage";
import { LoginPage } from "@/pages/LoginPage";
import { RegisterPage } from "@/pages/RegisterPage";
import { ForgotPasswordPage } from "@/pages/ForgotPasswordPage";
import { CoursesPage } from "@/pages/CoursesPage";
import { CourseDetailPage } from "@/pages/CourseDetailPage";
import { CoursePlayerPage } from "@/pages/CoursePlayerPage";
import { NotFoundPage } from "@/pages/NotFoundPage";

import { StudentDashboardHome } from "@/pages/student/StudentDashboardHome";
import { WishlistPage } from "@/pages/student/WishlistPage";
import { CertificatesPage } from "@/pages/student/CertificatesPage";

import { InstructorDashboardHome } from "@/pages/instructor/InstructorDashboardHome";
import { InstructorCoursesPage } from "@/pages/instructor/InstructorCoursesPage";
import { CourseEditorPage } from "@/pages/instructor/CourseEditorPage";

import { AdminDashboardHome } from "@/pages/admin/AdminDashboardHome";
import { AdminUsersPage } from "@/pages/admin/AdminUsersPage";
import { AdminModerationPage } from "@/pages/admin/AdminModerationPage";

import { ProfilePage } from "@/pages/shared/ProfilePage";
import { NotificationsPage } from "@/pages/shared/NotificationsPage";
import { MessagesPage } from "@/pages/shared/MessagesPage";
import { SearchPage } from "@/pages/shared/SearchPage";
import { CheckoutSuccessPage } from "@/pages/shared/CheckoutSuccessPage";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";

const studentNav = [
  { label: "Overview", to: "/dashboard", icon: LayoutDashboard, end: true },
  { label: "Wishlist", to: "/dashboard/wishlist", icon: Heart },
  { label: "Certificates", to: "/dashboard/certificates", icon: Award },
  { label: "Profile", to: "/dashboard/profile", icon: User },
];

const instructorNav = [
  { label: "Overview", to: "/instructor", icon: LayoutDashboard, end: true },
  { label: "My courses", to: "/instructor/courses", icon: BookOpen },
  { label: "Profile", to: "/instructor/profile", icon: User },
];

const adminNav = [
  { label: "Overview", to: "/admin", icon: BarChart3, end: true },
  { label: "Users", to: "/admin/users", icon: Users },
  { label: "Moderation", to: "/admin/moderation", icon: FileCheck },
];

export default function App() {
  const isDark = useThemeStore((s) => s.isDark);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/courses" element={<CoursesPage />} />
      <Route path="/courses/:slug" element={<CourseDetailPage />} />
      <Route path="/search" element={<SearchPage />} />
      <Route path="/checkout/success" element={<CheckoutSuccessPage />} />

      <Route element={<ProtectedRoute />}>
        <Route path="/courses/:slug/learn" element={<CoursePlayerPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/messages" element={<MessagesPage />} />
      </Route>

      <Route element={<ProtectedRoute allowedRoles={["STUDENT", "INSTRUCTOR", "ADMIN"]} />}>
        <Route path="/dashboard" element={<DashboardLayout navItems={studentNav} title="My learning" />}>
          <Route index element={<StudentDashboardHome />} />
          <Route path="wishlist" element={<WishlistPage />} />
          <Route path="certificates" element={<CertificatesPage />} />
          <Route path="profile" element={<ProfilePage />} />
        </Route>
      </Route>

      <Route element={<ProtectedRoute allowedRoles={["INSTRUCTOR", "ADMIN"]} />}>
        <Route path="/instructor" element={<DashboardLayout navItems={instructorNav} title="Teaching" />}>
          <Route index element={<InstructorDashboardHome />} />
          <Route path="courses" element={<InstructorCoursesPage />} />
          <Route path="courses/:id/edit" element={<CourseEditorPage />} />
          <Route path="profile" element={<ProfilePage />} />
        </Route>
      </Route>

      <Route element={<ProtectedRoute allowedRoles={["ADMIN"]} />}>
        <Route path="/admin" element={<DashboardLayout navItems={adminNav} title="Admin" />}>
          <Route index element={<AdminDashboardHome />} />
          <Route path="users" element={<AdminUsersPage />} />
          <Route path="moderation" element={<AdminModerationPage />} />
        </Route>
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
