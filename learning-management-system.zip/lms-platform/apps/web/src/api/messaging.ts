import { apiClient } from "./client";

export const messagingApi = {
  listConversations: () => apiClient.get("/messages/conversations").then((r) => r.data),
  startConversation: (userId: string) => apiClient.post("/messages/conversations", { userId }).then((r) => r.data),
  getMessages: (conversationId: string) =>
    apiClient.get(`/messages/conversations/${conversationId}/messages`).then((r) => r.data),
  sendMessage: (conversationId: string, content: string) =>
    apiClient.post(`/messages/conversations/${conversationId}/messages`, { content }).then((r) => r.data),
};
