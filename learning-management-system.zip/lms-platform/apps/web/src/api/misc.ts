import { apiClient } from "./client";

export const reviewsApi = {
  list: (courseId: string, page = 1) => apiClient.get(`/reviews/course/${courseId}`, { params: { page } }).then((r) => r.data),
  upsert: (courseId: string, rating: number, comment?: string) =>
    apiClient.post(`/reviews/course/${courseId}`, { rating, comment }).then((r) => r.data),
};

export const wishlistApi = {
  toggle: (courseId: string) => apiClient.post(`/wishlist/${courseId}/toggle`).then((r) => r.data),
  list: () => apiClient.get("/wishlist").then((r) => r.data),
};

export const notificationsApi = {
  list: () => apiClient.get("/notifications").then((r) => r.data),
  markRead: (id: string) => apiClient.patch(`/notifications/${id}/read`).then((r) => r.data),
  markAllRead: () => apiClient.patch("/notifications/read-all").then((r) => r.data),
};

export const paymentsApi = {
  checkout: (courseId: string) => apiClient.post("/payments/checkout", { courseId }).then((r) => r.data),
};

export const analyticsApi = {
  instructor: () => apiClient.get("/analytics/instructor").then((r) => r.data),
  admin: () => apiClient.get("/analytics/admin").then((r) => r.data),
};

export const adminApi = {
  listUsers: (params: any) => apiClient.get("/admin/users", { params }).then((r) => r.data),
  setUserActive: (userId: string, isActive: boolean) =>
    apiClient.patch(`/admin/users/${userId}/active`, { isActive }).then((r) => r.data),
  moderationQueue: () => apiClient.get("/admin/courses/moderation").then((r) => r.data),
  approveCourse: (courseId: string) => apiClient.post(`/admin/courses/${courseId}/approve`).then((r) => r.data),
  rejectCourse: (courseId: string, reason: string) =>
    apiClient.post(`/admin/courses/${courseId}/reject`, { reason }).then((r) => r.data),
};

export const certificatesApi = {
  mine: () => apiClient.get("/certificates/my").then((r) => r.data),
};

export const searchApi = {
  search: (q: string) => apiClient.get("/search", { params: { q } }).then((r) => r.data),
};
