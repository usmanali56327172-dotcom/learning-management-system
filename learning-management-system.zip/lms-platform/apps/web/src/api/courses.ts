import { apiClient } from "./client";

export interface CourseListParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
  level?: string;
  sort?: string;
}

export const coursesApi = {
  list: (params: CourseListParams) => apiClient.get("/courses", { params }).then((r) => r.data),
  getBySlug: (slug: string) => apiClient.get(`/courses/${slug}`).then((r) => r.data),
  myCourses: () => apiClient.get("/courses/my/courses").then((r) => r.data),
  create: (payload: any) => apiClient.post("/courses", payload).then((r) => r.data),
  update: (id: string, payload: any) => apiClient.patch(`/courses/${id}`, payload).then((r) => r.data),
  remove: (id: string) => apiClient.delete(`/courses/${id}`).then((r) => r.data),
  submitForReview: (id: string) => apiClient.post(`/courses/${id}/submit`).then((r) => r.data),
  addSection: (id: string, payload: { title: string }) =>
    apiClient.post(`/courses/${id}/sections`, payload).then((r) => r.data),
  addLesson: (sectionId: string, payload: any) =>
    apiClient.post(`/courses/sections/${sectionId}/lessons`, payload).then((r) => r.data),
};
