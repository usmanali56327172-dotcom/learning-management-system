import { apiClient } from "./client";

export const enrollmentsApi = {
  enrollFree: (courseId: string) => apiClient.post("/enrollments/free", { courseId }).then((r) => r.data),
  myEnrollments: () => apiClient.get("/enrollments/my").then((r) => r.data),
  learn: (slug: string) => apiClient.get(`/enrollments/learn/${slug}`).then((r) => r.data),
  status: (courseId: string) => apiClient.get(`/enrollments/status/${courseId}`).then((r) => r.data),
};

export const progressApi = {
  markLesson: (lessonId: string, payload: { isCompleted?: boolean; watchedSeconds?: number }) =>
    apiClient.patch(`/progress/lessons/${lessonId}`, payload).then((r) => r.data),
};
