import { apiClient } from "./client";

export const quizzesApi = {
  get: (lessonId: string) => apiClient.get(`/quizzes/lessons/${lessonId}`).then((r) => r.data),
  submitAttempt: (quizId: string, answers: Record<string, number>) =>
    apiClient.post(`/quizzes/${quizId}/attempts`, { answers }).then((r) => r.data),
  myAttempts: (quizId: string) => apiClient.get(`/quizzes/${quizId}/attempts/my`).then((r) => r.data),
};

export const assignmentsApi = {
  submit: (assignmentId: string, contentUrl: string, notes?: string) =>
    apiClient.post(`/assignments/${assignmentId}/submissions`, { contentUrl, notes }).then((r) => r.data),
};

export const quizAuthoringApi = {
  create: (
    lessonId: string,
    payload: { title: string; passingScore?: number; questions: { question: string; options: string[]; correctOption: number }[] }
  ) => apiClient.post(`/quizzes/lessons/${lessonId}`, payload).then((r) => r.data),
};

export const assignmentAuthoringApi = {
  create: (lessonId: string, payload: { title: string; instructions: string; maxScore?: number }) =>
    apiClient.post(`/assignments/lessons/${lessonId}`, payload).then((r) => r.data),
};

export const assignmentGradingApi = {
  listSubmissions: (assignmentId: string) =>
    apiClient.get(`/assignments/${assignmentId}/submissions`).then((r) => r.data),
  grade: (submissionId: string, score: number, feedback?: string) =>
    apiClient.patch(`/assignments/submissions/${submissionId}/grade`, { score, feedback }).then((r) => r.data),
};
