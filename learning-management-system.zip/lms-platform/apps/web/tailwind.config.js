/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14213D",
        paper: "#F7F6F2",
        parchment: "#EFEDE6",
        gold: {
          DEFAULT: "#C9A227",
          light: "#E0C05C",
          dark: "#9C7D1B",
        },
        forest: {
          DEFAULT: "#1B4332",
          light: "#2D6A4F",
          dark: "#10291F",
        },
        clay: "#B5533C",
        night: {
          bg: "#0B0F19",
          surface: "#131A2A",
          border: "#232C42",
        },
      },
      fontFamily: {
        display: ["Fraunces", "ui-serif", "Georgia", "serif"],
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
      boxShadow: {
        card: "0 2px 10px -2px rgba(20, 33, 61, 0.08), 0 1px 2px rgba(20,33,61,0.06)",
        "card-hover": "0 8px 24px -4px rgba(20, 33, 61, 0.16)",
      },
      keyframes: {
        fadeInUp: {
          "0%": { opacity: 0, transform: "translateY(12px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        },
      },
      animation: {
        fadeInUp: "fadeInUp 0.5s ease-out both",
      },
    },
  },
  plugins: [],
};
