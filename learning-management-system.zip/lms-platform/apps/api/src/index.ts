import http from "http";
import { createApp } from "@/app";
import { env } from "@/config/env";
import { logger } from "@/config/logger";
import { initSocket } from "@/realtime/socket";
import { prisma } from "@/config/prisma";

async function bootstrap() {
  const app = createApp();
  const server = http.createServer(app);

  initSocket(server);

  server.listen(env.port, () => {
    logger.info(`🚀 LMS API running on port ${env.port} [${env.nodeEnv}]`);
    logger.info(`📚 API docs available at http://localhost:${env.port}/api-docs`);
  });

  const shutdown = async (signal: string) => {
    logger.info(`${signal} received. Shutting down gracefully...`);
    server.close(async () => {
      await prisma.$disconnect();
      process.exit(0);
    });
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("unhandledRejection", (reason) => {
    logger.error("Unhandled Rejection", { reason });
  });
}

bootstrap();
