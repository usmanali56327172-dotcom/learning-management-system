import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { slugify } from "@/utils/slugify";
import { parsePagination, buildMeta } from "@/utils/pagination";
import { CourseStatus, Prisma } from "@prisma/client";

const PUBLIC_INCLUDE = {
  instructor: {
    select: { id: true, firstName: true, lastName: true, avatarUrl: true, headline: true },
  },
  category: true,
} satisfies Prisma.CourseInclude;

export async function listCourses(query: {
  page?: string;
  limit?: string;
  search?: string;
  category?: string;
  level?: string;
  minPrice?: string;
  maxPrice?: string;
  sort?: string;
  instructorId?: string;
  statusOverride?: CourseStatus[];
}) {
  const { page, limit, skip } = parsePagination(query);

  const where: Prisma.CourseWhereInput = {
    status: { in: query.statusOverride ?? [CourseStatus.PUBLISHED] },
    ...(query.instructorId ? { instructorId: query.instructorId } : {}),
    ...(query.category ? { category: { slug: query.category } } : {}),
    ...(query.level ? { level: query.level as any } : {}),
    ...(query.search
      ? {
          OR: [
            { title: { contains: query.search, mode: "insensitive" } },
            { tags: { has: query.search.toLowerCase() } },
            { description: { contains: query.search, mode: "insensitive" } },
          ],
        }
      : {}),
    ...(query.minPrice || query.maxPrice
      ? {
          price: {
            ...(query.minPrice ? { gte: parseFloat(query.minPrice) } : {}),
            ...(query.maxPrice ? { lte: parseFloat(query.maxPrice) } : {}),
          },
        }
      : {}),
  };

  const orderBy: Prisma.CourseOrderByWithRelationInput =
    query.sort === "popular"
      ? { enrollmentCount: "desc" }
      : query.sort === "rating"
      ? { averageRating: "desc" }
      : query.sort === "price_asc"
      ? { price: "asc" }
      : query.sort === "price_desc"
      ? { price: "desc" }
      : { publishedAt: "desc" };

  const [items, total] = await prisma.$transaction([
    prisma.course.findMany({ where, include: PUBLIC_INCLUDE, orderBy, skip, take: limit }),
    prisma.course.count({ where }),
  ]);

  return { items, meta: buildMeta(total, page, limit) };
}

export async function getCourseBySlug(slug: string) {
  const course = await prisma.course.findUnique({
    where: { slug },
    include: {
      ...PUBLIC_INCLUDE,
      sections: {
        orderBy: { order: "asc" },
        include: {
          lessons: {
            orderBy: { order: "asc" },
            include: {
              quiz: { select: { id: true, title: true } },
              assignment: { select: { id: true, title: true, maxScore: true } },
            },
          },
        },
      },
      reviews: {
        take: 10,
        orderBy: { createdAt: "desc" },
        include: { user: { select: { firstName: true, lastName: true, avatarUrl: true } } },
      },
    },
  });
  if (!course) throw ApiError.notFound("Course not found");
  return course;
}

export async function createCourse(instructorId: string, data: any) {
  const baseSlug = slugify(data.title);
  let slug = baseSlug;
  let attempt = 0;
  while (await prisma.course.findUnique({ where: { slug } })) {
    attempt += 1;
    slug = `${baseSlug}-${attempt}`;
  }

  return prisma.course.create({
    data: {
      ...data,
      slug,
      instructorId,
      status: CourseStatus.DRAFT,
    },
  });
}

async function assertOwnership(courseId: string, instructorId: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw ApiError.notFound("Course not found");
  if (course.instructorId !== instructorId) throw ApiError.forbidden("You do not own this course");
  return course;
}

export async function updateCourse(courseId: string, instructorId: string, data: any) {
  await assertOwnership(courseId, instructorId);
  return prisma.course.update({ where: { id: courseId }, data });
}

export async function deleteCourse(courseId: string, instructorId: string) {
  await assertOwnership(courseId, instructorId);
  await prisma.course.delete({ where: { id: courseId } });
}

export async function submitForReview(courseId: string, instructorId: string) {
  const course = await assertOwnership(courseId, instructorId);
  const sectionCount = await prisma.section.count({ where: { courseId } });
  if (sectionCount === 0) throw ApiError.badRequest("Add at least one section before submitting for review");

  return prisma.course.update({
    where: { id: courseId },
    data: { status: CourseStatus.PENDING_REVIEW },
  });
}

export async function getInstructorCourses(instructorId: string) {
  return prisma.course.findMany({
    where: { instructorId },
    orderBy: { updatedAt: "desc" },
    include: { category: true },
  });
}

// ---- Sections & Lessons ----

export async function addSection(courseId: string, instructorId: string, data: { title: string; order?: number }) {
  await assertOwnership(courseId, instructorId);
  const count = await prisma.section.count({ where: { courseId } });
  return prisma.section.create({
    data: { title: data.title, order: data.order ?? count, courseId },
  });
}

export async function addLesson(sectionId: string, instructorId: string, data: any) {
  const section = await prisma.section.findUnique({ where: { id: sectionId }, include: { course: true } });
  if (!section) throw ApiError.notFound("Section not found");
  if (section.course.instructorId !== instructorId) throw ApiError.forbidden("You do not own this course");

  const count = await prisma.lesson.count({ where: { sectionId } });
  const lesson = await prisma.lesson.create({
    data: { ...data, order: data.order ?? count, sectionId },
  });

  await recalcCourseStats(section.courseId);
  return lesson;
}

export async function recalcCourseStats(courseId: string) {
  const sections = await prisma.section.findMany({
    where: { courseId },
    include: { lessons: true },
  });
  const totalLessons = sections.reduce((acc, s) => acc + s.lessons.length, 0);
  const totalDuration = sections.reduce(
    (acc, s) => acc + s.lessons.reduce((a, l) => a + (l.videoDuration || 0), 0),
    0
  );
  await prisma.course.update({ where: { id: courseId }, data: { totalLessons, totalDuration } });
}
