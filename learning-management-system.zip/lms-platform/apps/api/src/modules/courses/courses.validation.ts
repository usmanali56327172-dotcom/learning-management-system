import { z } from "zod";

export const createCourseSchema = z.object({
  body: z.object({
    title: z.string().min(5).max(150),
    subtitle: z.string().max(200).optional(),
    description: z.string().min(20),
    price: z.number().min(0).default(0),
    discountPrice: z.number().min(0).optional(),
    level: z.enum(["BEGINNER", "INTERMEDIATE", "ADVANCED", "ALL_LEVELS"]).optional(),
    language: z.string().optional(),
    categoryId: z.string().uuid().optional(),
    requirements: z.array(z.string()).optional(),
    whatYouWillLearn: z.array(z.string()).optional(),
    targetAudience: z.array(z.string()).optional(),
    tags: z.array(z.string()).optional(),
    thumbnailUrl: z.string().url().optional(),
    promoVideoUrl: z.string().url().optional(),
  }),
});

export const updateCourseSchema = z.object({
  body: createCourseSchema.shape.body.partial(),
});

export const listCoursesQuerySchema = z.object({
  query: z.object({
    page: z.string().optional(),
    limit: z.string().optional(),
    search: z.string().optional(),
    category: z.string().optional(),
    level: z.string().optional(),
    minPrice: z.string().optional(),
    maxPrice: z.string().optional(),
    sort: z.enum(["newest", "popular", "rating", "price_asc", "price_desc"]).optional(),
    instructorId: z.string().uuid().optional(),
  }),
});

export const createSectionSchema = z.object({
  body: z.object({
    title: z.string().min(2).max(150),
    order: z.number().int().min(0).optional(),
  }),
});

export const createLessonSchema = z.object({
  body: z.object({
    title: z.string().min(2).max(150),
    type: z.enum(["VIDEO", "ARTICLE", "QUIZ", "ASSIGNMENT"]).default("VIDEO"),
    order: z.number().int().min(0).optional(),
    videoUrl: z.string().url().optional(),
    videoDuration: z.number().int().min(0).optional(),
    articleContent: z.string().optional(),
    isPreview: z.boolean().optional(),
    resources: z.array(z.object({ name: z.string(), url: z.string().url() })).optional(),
  }),
});
