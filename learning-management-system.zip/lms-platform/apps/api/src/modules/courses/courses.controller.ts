import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./courses.service";
import { CourseStatus } from "@prisma/client";

export const listCourses = catchAsync(async (req: Request, res: Response) => {
  const { items, meta } = await service.listCourses(req.query as any);
  sendSuccess(res, items, "Courses fetched", 200, meta);
});

export const getCourse = catchAsync(async (req: Request, res: Response) => {
  const course = await service.getCourseBySlug(req.params.slug);
  sendSuccess(res, course, "Course fetched");
});

export const createCourse = catchAsync(async (req: Request, res: Response) => {
  const course = await service.createCourse(req.user!.id, req.body);
  sendSuccess(res, course, "Course created as draft", 201);
});

export const updateCourse = catchAsync(async (req: Request, res: Response) => {
  const course = await service.updateCourse(req.params.id, req.user!.id, req.body);
  sendSuccess(res, course, "Course updated");
});

export const deleteCourse = catchAsync(async (req: Request, res: Response) => {
  await service.deleteCourse(req.params.id, req.user!.id);
  sendSuccess(res, null, "Course deleted");
});

export const submitForReview = catchAsync(async (req: Request, res: Response) => {
  const course = await service.submitForReview(req.params.id, req.user!.id);
  sendSuccess(res, course, "Course submitted for review");
});

export const myCourses = catchAsync(async (req: Request, res: Response) => {
  const courses = await service.getInstructorCourses(req.user!.id);
  sendSuccess(res, courses, "Instructor courses fetched");
});

export const addSection = catchAsync(async (req: Request, res: Response) => {
  const section = await service.addSection(req.params.id, req.user!.id, req.body);
  sendSuccess(res, section, "Section created", 201);
});

export const addLesson = catchAsync(async (req: Request, res: Response) => {
  const lesson = await service.addLesson(req.params.sectionId, req.user!.id, req.body);
  sendSuccess(res, lesson, "Lesson created", 201);
});
