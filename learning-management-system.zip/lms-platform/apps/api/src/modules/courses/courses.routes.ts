import { Router } from "express";
import { validate } from "@/middlewares/validate";
import { authenticate, authorize, optionalAuth } from "@/middlewares/auth";
import * as controller from "./courses.controller";
import {
  createCourseSchema,
  updateCourseSchema,
  listCoursesQuerySchema,
  createSectionSchema,
  createLessonSchema,
} from "./courses.validation";

const router = Router();

router.get("/", validate(listCoursesQuerySchema), controller.listCourses);
router.get("/my/courses", authenticate, authorize("INSTRUCTOR", "ADMIN"), controller.myCourses);
router.get("/:slug", optionalAuth, controller.getCourse);

router.post(
  "/",
  authenticate,
  authorize("INSTRUCTOR", "ADMIN"),
  validate(createCourseSchema),
  controller.createCourse
);
router.patch(
  "/:id",
  authenticate,
  authorize("INSTRUCTOR", "ADMIN"),
  validate(updateCourseSchema),
  controller.updateCourse
);
router.delete("/:id", authenticate, authorize("INSTRUCTOR", "ADMIN"), controller.deleteCourse);
router.post("/:id/submit", authenticate, authorize("INSTRUCTOR"), controller.submitForReview);

router.post(
  "/:id/sections",
  authenticate,
  authorize("INSTRUCTOR", "ADMIN"),
  validate(createSectionSchema),
  controller.addSection
);
router.post(
  "/sections/:sectionId/lessons",
  authenticate,
  authorize("INSTRUCTOR", "ADMIN"),
  validate(createLessonSchema),
  controller.addLesson
);

export default router;
