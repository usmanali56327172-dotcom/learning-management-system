import { prisma } from "@/config/prisma";

export async function createBookmark(userId: string, lessonId: string, timestampSec: number, note?: string) {
  return prisma.bookmark.create({ data: { userId, lessonId, timestampSec, note } });
}

export async function listBookmarks(userId: string, lessonId?: string) {
  return prisma.bookmark.findMany({
    where: { userId, ...(lessonId ? { lessonId } : {}) },
    orderBy: { createdAt: "desc" },
    include: { lesson: { select: { title: true, sectionId: true } } },
  });
}

export async function deleteBookmark(userId: string, id: string) {
  await prisma.bookmark.deleteMany({ where: { id, userId } });
}
