import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./bookmarks.controller";

const router = Router();
router.use(authenticate);
router.get("/", controller.list);
router.post("/", controller.create);
router.delete("/:id", controller.remove);

export default router;
