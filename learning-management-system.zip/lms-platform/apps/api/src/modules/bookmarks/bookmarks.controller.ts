import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./bookmarks.service";

export const create = catchAsync(async (req: Request, res: Response) => {
  const bookmark = await service.createBookmark(req.user!.id, req.body.lessonId, req.body.timestampSec, req.body.note);
  sendSuccess(res, bookmark, "Bookmark created", 201);
});

export const list = catchAsync(async (req: Request, res: Response) => {
  const bookmarks = await service.listBookmarks(req.user!.id, req.query.lessonId as string | undefined);
  sendSuccess(res, bookmarks, "Bookmarks fetched");
});

export const remove = catchAsync(async (req: Request, res: Response) => {
  await service.deleteBookmark(req.user!.id, req.params.id);
  sendSuccess(res, null, "Bookmark removed");
});
