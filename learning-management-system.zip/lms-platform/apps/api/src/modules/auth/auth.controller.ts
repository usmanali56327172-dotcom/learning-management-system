import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import { env } from "@/config/env";
import * as authService from "./auth.service";

const REFRESH_COOKIE_OPTS = {
  httpOnly: true,
  secure: env.isProd,
  sameSite: "lax" as const,
  path: "/api/v1/auth",
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

export const register = catchAsync(async (req: Request, res: Response) => {
  const { user, accessToken, refreshToken } = await authService.registerUser(req.body);
  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTS);
  sendSuccess(res, { user, accessToken }, "Account created successfully", 201);
});

export const login = catchAsync(async (req: Request, res: Response) => {
  const { email, password } = req.body;
  const { user, accessToken, refreshToken } = await authService.loginUser(email, password);
  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTS);
  sendSuccess(res, { user, accessToken }, "Logged in successfully");
});

export const refresh = catchAsync(async (req: Request, res: Response) => {
  const token = req.cookies?.refreshToken || req.body?.refreshToken;
  const { user, accessToken, refreshToken } = await authService.refreshAccessToken(token);
  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTS);
  sendSuccess(res, { user, accessToken }, "Token refreshed");
});

export const logout = catchAsync(async (req: Request, res: Response) => {
  const token = req.cookies?.refreshToken || req.body?.refreshToken;
  await authService.logoutUser(token);
  res.clearCookie("refreshToken", { path: "/api/v1/auth" });
  sendSuccess(res, null, "Logged out successfully");
});

export const forgotPassword = catchAsync(async (req: Request, res: Response) => {
  await authService.requestPasswordReset(req.body.email);
  sendSuccess(res, null, "If an account exists for that email, a reset link has been sent");
});

export const resetPassword = catchAsync(async (req: Request, res: Response) => {
  await authService.resetPassword(req.body.token, req.body.password);
  sendSuccess(res, null, "Password reset successfully");
});

export const me = catchAsync(async (req: Request, res: Response) => {
  sendSuccess(res, req.user, "Current user");
});
