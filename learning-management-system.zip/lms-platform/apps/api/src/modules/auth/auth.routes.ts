import { Router } from "express";
import { validate } from "@/middlewares/validate";
import { authenticate } from "@/middlewares/auth";
import { authLimiter } from "@/middlewares/rateLimiter";
import * as controller from "./auth.controller";
import {
  registerSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from "./auth.validation";

const router = Router();

/**
 * @openapi
 * /auth/register:
 *   post:
 *     summary: Register a new student or instructor account
 *     tags: [Auth]
 */
router.post("/register", authLimiter, validate(registerSchema), controller.register);

/**
 * @openapi
 * /auth/login:
 *   post:
 *     summary: Login with email and password
 *     tags: [Auth]
 */
router.post("/login", authLimiter, validate(loginSchema), controller.login);

router.post("/refresh", controller.refresh);
router.post("/logout", controller.logout);
router.post("/forgot-password", authLimiter, validate(forgotPasswordSchema), controller.forgotPassword);
router.post("/reset-password", authLimiter, validate(resetPasswordSchema), controller.resetPassword);
router.get("/me", authenticate, controller.me);

export default router;
