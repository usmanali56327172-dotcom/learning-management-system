import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./users.service";

export const getMyProfile = catchAsync(async (req: Request, res: Response) => {
  const profile = await service.getProfile(req.user!.id);
  sendSuccess(res, profile, "Profile fetched");
});

export const updateMyProfile = catchAsync(async (req: Request, res: Response) => {
  const profile = await service.updateProfile(req.user!.id, req.body);
  sendSuccess(res, profile, "Profile updated");
});

export const changePassword = catchAsync(async (req: Request, res: Response) => {
  await service.changePassword(req.user!.id, req.body.currentPassword, req.body.newPassword);
  sendSuccess(res, null, "Password changed successfully");
});

export const getInstructorProfile = catchAsync(async (req: Request, res: Response) => {
  const profile = await service.getPublicInstructorProfile(req.params.id);
  sendSuccess(res, profile, "Instructor profile fetched");
});
