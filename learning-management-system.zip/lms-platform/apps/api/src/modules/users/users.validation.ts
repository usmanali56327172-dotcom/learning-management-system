import { z } from "zod";

export const updateProfileSchema = z.object({
  body: z.object({
    firstName: z.string().min(2).max(50).optional(),
    lastName: z.string().min(2).max(50).optional(),
    headline: z.string().max(150).optional(),
    bio: z.string().max(2000).optional(),
    avatarUrl: z.string().url().optional(),
    timezone: z.string().optional(),
    socialLinks: z.record(z.string().url()).optional(),
  }),
});

export const changePasswordSchema = z.object({
  body: z.object({
    currentPassword: z.string().min(8),
    newPassword: z.string().min(8).max(100),
  }),
});
