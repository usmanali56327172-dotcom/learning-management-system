import bcrypt from "bcryptjs";
import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";

const PUBLIC_SELECT = {
  id: true, email: true, firstName: true, lastName: true, avatarUrl: true,
  headline: true, bio: true, role: true, timezone: true, socialLinks: true,
  createdAt: true, isEmailVerified: true,
};

export async function getProfile(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId }, select: PUBLIC_SELECT });
  if (!user) throw ApiError.notFound("User not found");
  return user;
}

export async function updateProfile(userId: string, data: any) {
  return prisma.user.update({ where: { id: userId }, data, select: PUBLIC_SELECT });
}

export async function changePassword(userId: string, currentPassword: string, newPassword: string) {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  const valid = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!valid) throw ApiError.badRequest("Current password is incorrect");

  const passwordHash = await bcrypt.hash(newPassword, 12);
  await prisma.user.update({ where: { id: userId }, data: { passwordHash } });
}

export async function getPublicInstructorProfile(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId, role: "INSTRUCTOR" },
    select: {
      id: true, firstName: true, lastName: true, avatarUrl: true, headline: true, bio: true,
      coursesAuthored: {
        where: { status: "PUBLISHED" },
        select: { id: true, title: true, slug: true, thumbnailUrl: true, averageRating: true, enrollmentCount: true, price: true },
      },
    },
  });
  if (!user) throw ApiError.notFound("Instructor not found");
  return user;
}
