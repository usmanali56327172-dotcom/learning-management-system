import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import { validate } from "@/middlewares/validate";
import * as controller from "./users.controller";
import { updateProfileSchema, changePasswordSchema } from "./users.validation";

const router = Router();

router.get("/me", authenticate, controller.getMyProfile);
router.patch("/me", authenticate, validate(updateProfileSchema), controller.updateMyProfile);
router.post("/me/change-password", authenticate, validate(changePasswordSchema), controller.changePassword);
router.get("/instructors/:id", controller.getInstructorProfile);

export default router;
