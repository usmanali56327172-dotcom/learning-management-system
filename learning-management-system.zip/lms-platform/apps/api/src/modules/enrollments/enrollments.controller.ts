import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./enrollments.service";

export const enrollFree = catchAsync(async (req: Request, res: Response) => {
  const enrollment = await service.enrollFreeCourse(req.user!.id, req.body.courseId);
  sendSuccess(res, enrollment, "Enrolled successfully", 201);
});

export const myEnrollments = catchAsync(async (req: Request, res: Response) => {
  const enrollments = await service.getMyEnrollments(req.user!.id);
  sendSuccess(res, enrollments, "Enrollments fetched");
});

export const learnCourse = catchAsync(async (req: Request, res: Response) => {
  const data = await service.getEnrollmentForLearning(req.user!.id, req.params.slug);
  sendSuccess(res, data, "Course content fetched");
});

export const enrollmentStatus = catchAsync(async (req: Request, res: Response) => {
  const status = await service.checkEnrollmentStatus(req.user!.id, req.params.courseId);
  sendSuccess(res, status, "Enrollment status fetched");
});
