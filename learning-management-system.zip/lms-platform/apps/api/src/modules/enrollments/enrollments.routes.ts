import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./enrollments.controller";

const router = Router();

router.use(authenticate);
router.post("/free", controller.enrollFree);
router.get("/my", controller.myEnrollments);
router.get("/learn/:slug", controller.learnCourse);
router.get("/status/:courseId", controller.enrollmentStatus);

export default router;
