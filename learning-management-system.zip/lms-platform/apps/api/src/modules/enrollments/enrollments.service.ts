import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { EnrollmentStatus } from "@prisma/client";
import { createNotification } from "@/modules/notifications/notifications.service";

export async function enrollFreeCourse(userId: string, courseId: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw ApiError.notFound("Course not found");
  if (Number(course.price) > 0) throw ApiError.badRequest("This course requires payment. Use the checkout endpoint.");

  const existing = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId, courseId } },
  });
  if (existing) throw ApiError.conflict("You are already enrolled in this course");

  const enrollment = await prisma.$transaction(async (tx) => {
    const e = await tx.enrollment.create({ data: { userId, courseId } });
    await tx.course.update({ where: { id: courseId }, data: { enrollmentCount: { increment: 1 } } });
    return e;
  });

  await createNotification({
    userId,
    type: "ENROLLMENT",
    title: "Enrollment confirmed",
    message: `You are now enrolled in "${course.title}".`,
    link: `/courses/${course.slug}/learn`,
  });

  return enrollment;
}

export async function getMyEnrollments(userId: string) {
  return prisma.enrollment.findMany({
    where: { userId },
    orderBy: { enrolledAt: "desc" },
    include: {
      course: {
        select: {
          id: true, title: true, slug: true, thumbnailUrl: true, totalLessons: true, totalDuration: true,
          instructor: { select: { firstName: true, lastName: true } },
        },
      },
    },
  });
}

export async function getEnrollmentForLearning(userId: string, courseSlug: string) {
  const course = await prisma.course.findUnique({
    where: { slug: courseSlug },
    include: {
      sections: {
        orderBy: { order: "asc" },
        include: {
          lessons: {
            orderBy: { order: "asc" },
            include: {
              quiz: { select: { id: true, title: true, passingScore: true } },
              assignment: { select: { id: true, title: true, instructions: true, maxScore: true } },
            },
          },
        },
      },
    },
  });
  if (!course) throw ApiError.notFound("Course not found");

  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId, courseId: course.id } },
  });
  if (!enrollment) throw ApiError.forbidden("You are not enrolled in this course");

  const lessonIds = course.sections.flatMap((s) => s.lessons.map((l) => l.id));
  const progressRecords = await prisma.lessonProgress.findMany({
    where: { userId, lessonId: { in: lessonIds } },
  });

  await prisma.enrollment.update({ where: { id: enrollment.id }, data: { lastAccessed: new Date() } });

  return { course, enrollment, progress: progressRecords };
}

export async function checkEnrollmentStatus(userId: string, courseId: string) {
  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId, courseId } },
  });
  return { enrolled: !!enrollment, status: enrollment?.status };
}
