import { Router } from "express";
import { authenticate, authorize } from "@/middlewares/auth";
import * as controller from "./admin.controller";

const router = Router();
router.use(authenticate, authorize("ADMIN"));

router.get("/users", controller.listUsers);
router.patch("/users/:userId/active", controller.setUserActive);
router.patch("/users/:userId/role", controller.changeUserRole);

router.get("/courses/moderation", controller.moderationQueue);
router.post("/courses/:courseId/approve", controller.approveCourse);
router.post("/courses/:courseId/reject", controller.rejectCourse);

router.get("/audit-log", controller.auditLog);

export default router;
