import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./admin.service";

export const listUsers = catchAsync(async (req: Request, res: Response) => {
  const { items, meta } = await service.listUsers(req.query as any);
  sendSuccess(res, items, "Users fetched", 200, meta);
});

export const setUserActive = catchAsync(async (req: Request, res: Response) => {
  const user = await service.setUserActiveStatus(req.user!.id, req.params.userId, req.body.isActive);
  sendSuccess(res, user, "User status updated");
});

export const changeUserRole = catchAsync(async (req: Request, res: Response) => {
  const user = await service.changeUserRole(req.user!.id, req.params.userId, req.body.role);
  sendSuccess(res, user, "User role updated");
});

export const moderationQueue = catchAsync(async (req: Request, res: Response) => {
  const courses = await service.listCoursesForModeration(req.query.status as string | undefined);
  sendSuccess(res, courses, "Moderation queue fetched");
});

export const approveCourse = catchAsync(async (req: Request, res: Response) => {
  const course = await service.approveCourse(req.user!.id, req.params.courseId);
  sendSuccess(res, course, "Course approved");
});

export const rejectCourse = catchAsync(async (req: Request, res: Response) => {
  const course = await service.rejectCourse(req.user!.id, req.params.courseId, req.body.reason);
  sendSuccess(res, course, "Course rejected");
});

export const auditLog = catchAsync(async (req: Request, res: Response) => {
  const logs = await service.getAuditLog(
    parseInt((req.query.page as string) || "1", 10),
    parseInt((req.query.limit as string) || "50", 10)
  );
  sendSuccess(res, logs, "Audit log fetched");
});
