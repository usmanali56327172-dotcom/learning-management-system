import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { createNotification } from "@/modules/notifications/notifications.service";
import { parsePagination, buildMeta } from "@/utils/pagination";

async function logAction(adminId: string, action: string, targetType: string, targetId: string, metadata?: any) {
  await prisma.adminAuditLog.create({ data: { adminId, action, targetType, targetId, metadata } });
}

export async function listUsers(query: { page?: string; limit?: string; role?: string; search?: string }) {
  const { page, limit, skip } = parsePagination(query);
  const where = {
    ...(query.role ? { role: query.role as any } : {}),
    ...(query.search
      ? {
          OR: [
            { email: { contains: query.search, mode: "insensitive" as const } },
            { firstName: { contains: query.search, mode: "insensitive" as const } },
            { lastName: { contains: query.search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };
  const [items, total] = await prisma.$transaction([
    prisma.user.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: "desc" },
      select: {
        id: true, email: true, firstName: true, lastName: true, role: true,
        isActive: true, isEmailVerified: true, createdAt: true,
      },
    }),
    prisma.user.count({ where }),
  ]);
  return { items, meta: buildMeta(total, page, limit) };
}

export async function setUserActiveStatus(adminId: string, userId: string, isActive: boolean) {
  const user = await prisma.user.update({ where: { id: userId }, data: { isActive } });
  await logAction(adminId, isActive ? "USER_ACTIVATED" : "USER_DEACTIVATED", "User", userId);
  return user;
}

export async function changeUserRole(adminId: string, userId: string, role: "STUDENT" | "INSTRUCTOR" | "ADMIN") {
  const user = await prisma.user.update({ where: { id: userId }, data: { role } });
  await logAction(adminId, "ROLE_CHANGED", "User", userId, { role });
  return user;
}

export async function listCoursesForModeration(status?: string) {
  return prisma.course.findMany({
    where: status ? { status: status as any } : { status: { in: ["PENDING_REVIEW"] } },
    include: { instructor: { select: { firstName: true, lastName: true, email: true } } },
    orderBy: { updatedAt: "asc" },
  });
}

export async function approveCourse(adminId: string, courseId: string) {
  const course = await prisma.course.update({
    where: { id: courseId },
    data: { status: "PUBLISHED", publishedAt: new Date(), rejectionReason: null },
  });
  await logAction(adminId, "COURSE_APPROVED", "Course", courseId);
  await createNotification({
    userId: course.instructorId,
    type: "COURSE_APPROVED",
    title: "Course approved!",
    message: `Your course "${course.title}" is now live on the platform.`,
    link: `/courses/${course.slug}`,
  });
  return course;
}

export async function rejectCourse(adminId: string, courseId: string, reason: string) {
  const course = await prisma.course.update({
    where: { id: courseId },
    data: { status: "REJECTED", rejectionReason: reason },
  });
  await logAction(adminId, "COURSE_REJECTED", "Course", courseId, { reason });
  await createNotification({
    userId: course.instructorId,
    type: "COURSE_REJECTED",
    title: "Course needs changes",
    message: `Your course "${course.title}" was not approved: ${reason}`,
    link: `/instructor/courses/${course.id}/edit`,
  });
  return course;
}

export async function getAuditLog(page = 1, limit = 50) {
  const skip = (page - 1) * limit;
  return prisma.adminAuditLog.findMany({
    skip,
    take: limit,
    orderBy: { createdAt: "desc" },
    include: { admin: { select: { firstName: true, lastName: true } } },
  });
}
