import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./messaging.service";

export const startConversation = catchAsync(async (req: Request, res: Response) => {
  const conversation = await service.getOrCreateConversation(req.user!.id, req.body.userId);
  sendSuccess(res, conversation, "Conversation ready");
});

export const listConversations = catchAsync(async (req: Request, res: Response) => {
  const conversations = await service.listMyConversations(req.user!.id);
  sendSuccess(res, conversations, "Conversations fetched");
});

export const getMessages = catchAsync(async (req: Request, res: Response) => {
  const messages = await service.getMessages(req.user!.id, req.params.conversationId);
  sendSuccess(res, messages, "Messages fetched");
});

export const sendMessage = catchAsync(async (req: Request, res: Response) => {
  const message = await service.sendMessage(req.user!.id, req.params.conversationId, req.body.content);
  sendSuccess(res, message, "Message sent", 201);
});
