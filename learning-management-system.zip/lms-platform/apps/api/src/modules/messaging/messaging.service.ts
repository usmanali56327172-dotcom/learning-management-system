import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { getIO } from "@/realtime/socket";
import { createNotification } from "@/modules/notifications/notifications.service";

export async function getOrCreateConversation(userId: string, otherUserId: string) {
  if (userId === otherUserId) throw ApiError.badRequest("Cannot message yourself");

  const existing = await prisma.conversation.findFirst({
    where: {
      AND: [
        { participants: { some: { userId } } },
        { participants: { some: { userId: otherUserId } } },
      ],
    },
  });
  if (existing) return existing;

  return prisma.conversation.create({
    data: { participants: { create: [{ userId }, { userId: otherUserId }] } },
  });
}

export async function listMyConversations(userId: string) {
  return prisma.conversation.findMany({
    where: { participants: { some: { userId } } },
    orderBy: { updatedAt: "desc" },
    include: {
      participants: { include: { user: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } } } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 },
    },
  });
}

export async function getMessages(userId: string, conversationId: string) {
  const participant = await prisma.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId } },
  });
  if (!participant) throw ApiError.forbidden("You are not part of this conversation");

  await prisma.message.updateMany({
    where: { conversationId, senderId: { not: userId }, isRead: false },
    data: { isRead: true },
  });

  return prisma.message.findMany({ where: { conversationId }, orderBy: { createdAt: "asc" } });
}

export async function sendMessage(senderId: string, conversationId: string, content: string) {
  const participant = await prisma.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId: senderId } },
  });
  if (!participant) throw ApiError.forbidden("You are not part of this conversation");

  const message = await prisma.message.create({ data: { conversationId, senderId, content } });
  await prisma.conversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } });

  const others = await prisma.conversationParticipant.findMany({
    where: { conversationId, userId: { not: senderId } },
  });

  for (const p of others) {
    getIO()?.to(`user:${p.userId}`).emit("message:new", message);
    await createNotification({
      userId: p.userId,
      type: "NEW_MESSAGE",
      title: "New message",
      message: content.slice(0, 100),
      link: `/messages/${conversationId}`,
    });
  }

  return message;
}
