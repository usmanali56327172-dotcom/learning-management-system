import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./messaging.controller";

const router = Router();
router.use(authenticate);
router.post("/conversations", controller.startConversation);
router.get("/conversations", controller.listConversations);
router.get("/conversations/:conversationId/messages", controller.getMessages);
router.post("/conversations/:conversationId/messages", controller.sendMessage);

export default router;
