import { Router } from "express";
import { authenticate, authorize } from "@/middlewares/auth";
import * as controller from "./analytics.controller";

const router = Router();
router.use(authenticate);
router.get("/instructor", authorize("INSTRUCTOR", "ADMIN"), controller.instructorAnalytics);
router.get("/admin", authorize("ADMIN"), controller.adminAnalytics);

export default router;
