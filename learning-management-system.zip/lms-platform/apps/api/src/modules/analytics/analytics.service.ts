import { prisma } from "@/config/prisma";

export async function getInstructorAnalytics(instructorId: string) {
  const courses = await prisma.course.findMany({
    where: { instructorId },
    select: { id: true, title: true, enrollmentCount: true, averageRating: true, price: true, status: true },
  });

  const courseIds = courses.map((c) => c.id);

  const [totalStudents, revenueAgg, reviewCount] = await Promise.all([
    prisma.enrollment.count({ where: { courseId: { in: courseIds } } }),
    prisma.payment.aggregate({
      where: { status: "SUCCEEDED", enrollment: { courseId: { in: courseIds } } },
      _sum: { amount: true },
    }),
    prisma.review.count({ where: { courseId: { in: courseIds } } }),
  ]);

  const enrollmentsByMonth = await prisma.$queryRawUnsafe<{ month: string; count: bigint }[]>(
    `SELECT to_char("enrolledAt", 'YYYY-MM') as month, COUNT(*) as count
     FROM enrollments WHERE "courseId" = ANY($1::text[])
     GROUP BY month ORDER BY month ASC LIMIT 12`,
    courseIds
  );

  return {
    totalCourses: courses.length,
    publishedCourses: courses.filter((c) => c.status === "PUBLISHED").length,
    totalStudents,
    totalRevenue: revenueAgg._sum.amount || 0,
    totalReviews: reviewCount,
    coursePerformance: courses,
    enrollmentTrend: enrollmentsByMonth.map((r) => ({ month: r.month, count: Number(r.count) })),
  };
}

export async function getAdminAnalytics() {
  const [totalUsers, totalStudents, totalInstructors, totalCourses, publishedCourses, revenueAgg, totalEnrollments] =
    await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { role: "STUDENT" } }),
      prisma.user.count({ where: { role: "INSTRUCTOR" } }),
      prisma.course.count(),
      prisma.course.count({ where: { status: "PUBLISHED" } }),
      prisma.payment.aggregate({ where: { status: "SUCCEEDED" }, _sum: { amount: true } }),
      prisma.enrollment.count(),
    ]);

  const signupsByMonth = await prisma.$queryRawUnsafe<{ month: string; count: bigint }[]>(
    `SELECT to_char("createdAt", 'YYYY-MM') as month, COUNT(*) as count
     FROM users GROUP BY month ORDER BY month ASC LIMIT 12`
  );

  return {
    totalUsers,
    totalStudents,
    totalInstructors,
    totalCourses,
    publishedCourses,
    totalRevenue: revenueAgg._sum.amount || 0,
    totalEnrollments,
    signupTrend: signupsByMonth.map((r) => ({ month: r.month, count: Number(r.count) })),
  };
}
