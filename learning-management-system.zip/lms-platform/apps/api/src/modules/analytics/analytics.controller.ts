import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./analytics.service";

export const instructorAnalytics = catchAsync(async (req: Request, res: Response) => {
  const data = await service.getInstructorAnalytics(req.user!.id);
  sendSuccess(res, data, "Instructor analytics fetched");
});

export const adminAnalytics = catchAsync(async (req: Request, res: Response) => {
  const data = await service.getAdminAnalytics();
  sendSuccess(res, data, "Platform analytics fetched");
});
