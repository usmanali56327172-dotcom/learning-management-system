import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./wishlist.controller";

const router = Router();
router.use(authenticate);
router.get("/", controller.list);
router.post("/:courseId/toggle", controller.toggle);

export default router;
