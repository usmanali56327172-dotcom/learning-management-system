import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./wishlist.service";

export const toggle = catchAsync(async (req: Request, res: Response) => {
  const result = await service.toggleWishlist(req.user!.id, req.params.courseId);
  sendSuccess(res, result, "Wishlist updated");
});

export const list = catchAsync(async (req: Request, res: Response) => {
  const items = await service.getWishlist(req.user!.id);
  sendSuccess(res, items, "Wishlist fetched");
});
