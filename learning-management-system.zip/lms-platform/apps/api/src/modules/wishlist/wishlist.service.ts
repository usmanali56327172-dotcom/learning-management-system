import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";

export async function toggleWishlist(userId: string, courseId: string) {
  const existing = await prisma.wishlistItem.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (existing) {
    await prisma.wishlistItem.delete({ where: { id: existing.id } });
    return { wishlisted: false };
  }
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw ApiError.notFound("Course not found");
  await prisma.wishlistItem.create({ data: { userId, courseId } });
  return { wishlisted: true };
}

export async function getWishlist(userId: string) {
  return prisma.wishlistItem.findMany({
    where: { userId },
    orderBy: { addedAt: "desc" },
    include: {
      course: {
        select: {
          id: true, title: true, slug: true, thumbnailUrl: true, price: true, discountPrice: true,
          averageRating: true, reviewCount: true,
          instructor: { select: { firstName: true, lastName: true } },
        },
      },
    },
  });
}
