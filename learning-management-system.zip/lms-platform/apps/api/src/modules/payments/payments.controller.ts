import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./payments.service";
import { env } from "@/config/env";
import { logger } from "@/config/logger";

export const checkout = catchAsync(async (req: Request, res: Response) => {
  const result = await service.createCheckoutSession(req.user!.id, req.body.courseId);
  sendSuccess(res, result, "Checkout session created");
});

export const myPayments = catchAsync(async (req: Request, res: Response) => {
  const payments = await service.getMyPayments(req.user!.id);
  sendSuccess(res, payments, "Payments fetched");
});

/** Stripe requires the raw body for signature verification — handled in app.ts */
export const webhook = catchAsync(async (req: Request, res: Response) => {
  const sig = req.headers["stripe-signature"] as string;
  let event;
  try {
    event = service.stripe.webhooks.constructEvent(req.body, sig, env.stripe.webhookSecret);
  } catch (err) {
    logger.error("Stripe webhook signature verification failed", { err });
    return res.status(400).send(`Webhook Error: ${(err as Error).message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as { id: string };
    await service.fulfillCheckout(session.id);
  }

  res.json({ received: true });
});
