import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./payments.controller";

const router = Router();

router.post("/checkout", authenticate, controller.checkout);
router.get("/my", authenticate, controller.myPayments);
// NOTE: webhook route is mounted separately in app.ts with raw body parsing

export default router;
