import Stripe from "stripe";
import { prisma } from "@/config/prisma";
import { env } from "@/config/env";
import { ApiError } from "@/utils/ApiError";
import { createNotification } from "@/modules/notifications/notifications.service";

export const stripe = new Stripe(env.stripe.secretKey || "sk_test_placeholder", {
  apiVersion: "2024-06-20",
});

export async function createCheckoutSession(userId: string, courseId: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw ApiError.notFound("Course not found");

  const existing = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (existing) throw ApiError.conflict("You are already enrolled in this course");

  const price = course.discountPrice ?? course.price;
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    customer_email: user.email,
    line_items: [
      {
        price_data: {
          currency: course.currency.toLowerCase(),
          product_data: { name: course.title, images: course.thumbnailUrl ? [course.thumbnailUrl] : [] },
          unit_amount: Math.round(Number(price) * 100),
        },
        quantity: 1,
      },
    ],
    metadata: { userId, courseId },
    success_url: `${env.clientUrl}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${env.clientUrl}/courses/${course.slug}`,
  });

  await prisma.payment.create({
    data: {
      userId,
      amount: price,
      currency: course.currency,
      status: "PENDING",
      stripeCheckoutId: session.id,
    },
  });

  return { checkoutUrl: session.url };
}

/** Called from the Stripe webhook once payment is confirmed. */
export async function fulfillCheckout(sessionId: string) {
  const session = await stripe.checkout.sessions.retrieve(sessionId);
  const { userId, courseId } = session.metadata || {};
  if (!userId || !courseId) throw ApiError.badRequest("Missing session metadata");

  const payment = await prisma.payment.findFirst({ where: { stripeCheckoutId: sessionId } });
  if (!payment || payment.status === "SUCCEEDED") return; // idempotent

  await prisma.$transaction(async (tx) => {
    const enrollment = await tx.enrollment.create({ data: { userId, courseId } });
    await tx.course.update({ where: { id: courseId }, data: { enrollmentCount: { increment: 1 } } });
    await tx.payment.update({
      where: { id: payment.id },
      data: {
        status: "SUCCEEDED",
        enrollmentId: enrollment.id,
        stripePaymentIntentId: session.payment_intent as string,
      },
    });
  });

  const course = await prisma.course.findUnique({ where: { id: courseId } });
  await createNotification({
    userId,
    type: "PAYMENT",
    title: "Payment successful",
    message: `Your payment for "${course?.title}" was successful. You're now enrolled!`,
    link: `/courses/${course?.slug}/learn`,
  });
}

export async function getMyPayments(userId: string) {
  return prisma.payment.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
}
