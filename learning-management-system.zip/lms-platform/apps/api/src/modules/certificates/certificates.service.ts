import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { createNotification } from "@/modules/notifications/notifications.service";
import crypto from "crypto";

export async function issueCertificateIfEligible(userId: string, courseId: string, enrollmentId: string) {
  const existing = await prisma.certificate.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (existing) return existing;

  const serialNumber = `CERT-${crypto.randomBytes(6).toString("hex").toUpperCase()}`;
  const certificate = await prisma.certificate.create({
    data: { userId, courseId, enrollmentId, serialNumber },
  });

  const course = await prisma.course.findUnique({ where: { id: courseId } });
  await createNotification({
    userId,
    type: "CERTIFICATE_ISSUED",
    title: "Certificate earned!",
    message: `Congratulations! You've earned a certificate for completing "${course?.title}".`,
    link: `/certificates/${certificate.id}`,
  });

  return certificate;
}

export async function getMyCertificates(userId: string) {
  return prisma.certificate.findMany({
    where: { userId },
    orderBy: { issuedAt: "desc" },
    include: { course: { select: { title: true, slug: true, thumbnailUrl: true } } },
  });
}

export async function verifyCertificate(serialNumber: string) {
  const cert = await prisma.certificate.findUnique({
    where: { serialNumber },
    include: {
      course: { select: { title: true } },
      user: { select: { firstName: true, lastName: true } },
    },
  });
  if (!cert) throw ApiError.notFound("Certificate not found or invalid");
  return cert;
}
