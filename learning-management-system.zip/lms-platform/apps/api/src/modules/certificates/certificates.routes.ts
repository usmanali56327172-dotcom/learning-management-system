import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./certificates.controller";

const router = Router();
router.get("/my", authenticate, controller.myCertificates);
router.get("/verify/:serialNumber", controller.verify);

export default router;
