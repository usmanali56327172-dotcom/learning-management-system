import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./certificates.service";

export const myCertificates = catchAsync(async (req: Request, res: Response) => {
  const certs = await service.getMyCertificates(req.user!.id);
  sendSuccess(res, certs, "Certificates fetched");
});

export const verify = catchAsync(async (req: Request, res: Response) => {
  const cert = await service.verifyCertificate(req.params.serialNumber);
  sendSuccess(res, cert, "Certificate verified");
});
