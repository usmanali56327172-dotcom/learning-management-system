import { Router } from "express";
import { authenticate, authorize } from "@/middlewares/auth";
import { validate } from "@/middlewares/validate";
import * as controller from "./quizzes.controller";
import { createQuizSchema, submitAttemptSchema } from "./quizzes.validation";

const router = Router();
router.use(authenticate);

router.post("/lessons/:lessonId", authorize("INSTRUCTOR", "ADMIN"), validate(createQuizSchema), controller.createQuiz);
router.get("/lessons/:lessonId", controller.getQuiz);
router.post("/:quizId/attempts", validate(submitAttemptSchema), controller.submitAttempt);
router.get("/:quizId/attempts/my", controller.myAttempts);

export default router;
