import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";

export async function createQuiz(lessonId: string, instructorId: string, data: any) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    include: { section: { include: { course: true } } },
  });
  if (!lesson) throw ApiError.notFound("Lesson not found");
  if (lesson.section.course.instructorId !== instructorId) throw ApiError.forbidden();

  return prisma.quiz.create({
    data: {
      lessonId,
      title: data.title,
      passingScore: data.passingScore ?? 70,
      timeLimitSec: data.timeLimitSec,
      questions: {
        create: data.questions.map((q: any, idx: number) => ({
          question: q.question,
          options: q.options,
          correctOption: q.correctOption,
          order: idx,
        })),
      },
    },
    include: { questions: true },
  });
}

export async function getQuizForStudent(lessonId: string) {
  const quiz = await prisma.quiz.findUnique({
    where: { lessonId },
    include: { questions: { select: { id: true, question: true, options: true, order: true }, orderBy: { order: "asc" } } },
  });
  if (!quiz) throw ApiError.notFound("Quiz not found");
  return quiz;
}

export async function submitQuizAttempt(userId: string, quizId: string, answers: Record<string, number>) {
  const quiz = await prisma.quiz.findUnique({ where: { id: quizId }, include: { questions: true } });
  if (!quiz) throw ApiError.notFound("Quiz not found");

  let correct = 0;
  for (const q of quiz.questions) {
    if (answers[q.id] === q.correctOption) correct += 1;
  }
  const score = Math.round((correct / quiz.questions.length) * 100);
  const passed = score >= quiz.passingScore;

  return prisma.quizAttempt.create({
    data: { quizId, userId, answers, score, passed },
  });
}

export async function getMyAttempts(userId: string, quizId: string) {
  return prisma.quizAttempt.findMany({ where: { userId, quizId }, orderBy: { attemptedAt: "desc" } });
}
