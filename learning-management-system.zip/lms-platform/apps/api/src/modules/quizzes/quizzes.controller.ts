import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./quizzes.service";

export const createQuiz = catchAsync(async (req: Request, res: Response) => {
  const quiz = await service.createQuiz(req.params.lessonId, req.user!.id, req.body);
  sendSuccess(res, quiz, "Quiz created", 201);
});

export const getQuiz = catchAsync(async (req: Request, res: Response) => {
  const quiz = await service.getQuizForStudent(req.params.lessonId);
  sendSuccess(res, quiz, "Quiz fetched");
});

export const submitAttempt = catchAsync(async (req: Request, res: Response) => {
  const attempt = await service.submitQuizAttempt(req.user!.id, req.params.quizId, req.body.answers);
  sendSuccess(res, attempt, "Quiz submitted", 201);
});

export const myAttempts = catchAsync(async (req: Request, res: Response) => {
  const attempts = await service.getMyAttempts(req.user!.id, req.params.quizId);
  sendSuccess(res, attempts, "Attempts fetched");
});
