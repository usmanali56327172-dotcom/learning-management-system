import { z } from "zod";

export const createQuizSchema = z.object({
  body: z.object({
    title: z.string().min(3).max(150),
    passingScore: z.number().int().min(0).max(100).optional(),
    timeLimitSec: z.number().int().min(0).optional(),
    questions: z
      .array(
        z.object({
          question: z.string().min(1),
          options: z.array(z.string().min(1)).min(2, "Each question needs at least 2 options"),
          correctOption: z.number().int().min(0),
        })
      )
      .min(1, "A quiz needs at least one question"),
  }),
});

export const submitAttemptSchema = z.object({
  body: z.object({
    answers: z.record(z.string(), z.number().int().min(0)),
  }),
});
