import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./reviews.controller";

const router = Router();

router.get("/course/:courseId", controller.listReviews);
router.post("/course/:courseId", authenticate, controller.upsertReview);
router.delete("/:reviewId", authenticate, controller.deleteReview);

export default router;
