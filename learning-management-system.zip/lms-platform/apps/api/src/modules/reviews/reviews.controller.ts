import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./reviews.service";

export const upsertReview = catchAsync(async (req: Request, res: Response) => {
  const review = await service.upsertReview(req.user!.id, req.params.courseId, req.body.rating, req.body.comment);
  sendSuccess(res, review, "Review submitted");
});

export const listReviews = catchAsync(async (req: Request, res: Response) => {
  const page = parseInt((req.query.page as string) || "1", 10);
  const limit = parseInt((req.query.limit as string) || "10", 10);
  const data = await service.listCourseReviews(req.params.courseId, page, limit);
  sendSuccess(res, data.items, "Reviews fetched", 200, { total: data.total, page, limit });
});

export const deleteReview = catchAsync(async (req: Request, res: Response) => {
  await service.deleteReview(req.user!.id, req.params.reviewId);
  sendSuccess(res, null, "Review deleted");
});
