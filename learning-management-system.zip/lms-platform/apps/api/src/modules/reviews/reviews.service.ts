import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { createNotification } from "@/modules/notifications/notifications.service";

async function recalcCourseRating(courseId: string) {
  const agg = await prisma.review.aggregate({
    where: { courseId },
    _avg: { rating: true },
    _count: { rating: true },
  });
  await prisma.course.update({
    where: { id: courseId },
    data: { averageRating: agg._avg.rating || 0, reviewCount: agg._count.rating },
  });
}

export async function upsertReview(userId: string, courseId: string, rating: number, comment?: string) {
  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId, courseId } },
  });
  if (!enrollment) throw ApiError.forbidden("Only enrolled students can review this course");

  const review = await prisma.review.upsert({
    where: { userId_courseId: { userId, courseId } },
    update: { rating, comment },
    create: { userId, courseId, rating, comment },
  });

  await recalcCourseRating(courseId);

  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (course) {
    await createNotification({
      userId: course.instructorId,
      type: "NEW_REVIEW",
      title: "New course review",
      message: `Your course "${course.title}" received a new ${rating}-star review.`,
      link: `/courses/${course.slug}`,
    });
  }

  return review;
}

export async function listCourseReviews(courseId: string, page = 1, limit = 10) {
  const skip = (page - 1) * limit;
  const [items, total] = await prisma.$transaction([
    prisma.review.findMany({
      where: { courseId },
      orderBy: { createdAt: "desc" },
      skip,
      take: limit,
      include: { user: { select: { firstName: true, lastName: true, avatarUrl: true } } },
    }),
    prisma.review.count({ where: { courseId } }),
  ]);
  return { items, total };
}

export async function deleteReview(userId: string, reviewId: string) {
  const review = await prisma.review.findUnique({ where: { id: reviewId } });
  if (!review) throw ApiError.notFound("Review not found");
  if (review.userId !== userId) throw ApiError.forbidden("You can only delete your own review");

  await prisma.review.delete({ where: { id: reviewId } });
  await recalcCourseRating(review.courseId);
}
