import { Router } from "express";
import { authenticate } from "@/middlewares/auth";
import * as controller from "./progress.controller";

const router = Router();
router.use(authenticate);
router.patch("/lessons/:lessonId", controller.markProgress);

export default router;
