import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { issueCertificateIfEligible } from "@/modules/certificates/certificates.service";

export async function markLessonProgress(
  userId: string,
  lessonId: string,
  data: { isCompleted?: boolean; watchedSeconds?: number }
) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    include: { section: { include: { course: true } } },
  });
  if (!lesson) throw ApiError.notFound("Lesson not found");

  const courseId = lesson.section.courseId;
  const enrollment = await prisma.enrollment.findUnique({
    where: { userId_courseId: { userId, courseId } },
  });
  if (!enrollment) throw ApiError.forbidden("You are not enrolled in this course");

  const progress = await prisma.lessonProgress.upsert({
    where: { userId_lessonId: { userId, lessonId } },
    update: {
      isCompleted: data.isCompleted ?? undefined,
      watchedSeconds: data.watchedSeconds ?? undefined,
      completedAt: data.isCompleted ? new Date() : undefined,
    },
    create: {
      userId,
      lessonId,
      isCompleted: data.isCompleted ?? false,
      watchedSeconds: data.watchedSeconds ?? 0,
      completedAt: data.isCompleted ? new Date() : null,
    },
  });

  await recalcEnrollmentProgress(userId, courseId);
  return progress;
}

export async function recalcEnrollmentProgress(userId: string, courseId: string) {
  const totalLessons = await prisma.lesson.count({ where: { section: { courseId } } });
  const completedLessons = await prisma.lessonProgress.count({
    where: { userId, isCompleted: true, lesson: { section: { courseId } } },
  });

  const progressPct = totalLessons === 0 ? 0 : Math.round((completedLessons / totalLessons) * 100);
  const isComplete = progressPct >= 100;

  const enrollment = await prisma.enrollment.update({
    where: { userId_courseId: { userId, courseId } },
    data: {
      progressPct,
      status: isComplete ? "COMPLETED" : undefined,
      completedAt: isComplete ? new Date() : undefined,
    },
  });

  if (isComplete) {
    await issueCertificateIfEligible(userId, courseId, enrollment.id);
  }

  return enrollment;
}
