import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./progress.service";

export const markProgress = catchAsync(async (req: Request, res: Response) => {
  const progress = await service.markLessonProgress(req.user!.id, req.params.lessonId, req.body);
  sendSuccess(res, progress, "Progress updated");
});
