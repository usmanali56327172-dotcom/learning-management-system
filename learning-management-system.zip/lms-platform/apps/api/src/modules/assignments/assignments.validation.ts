import { z } from "zod";

export const createAssignmentSchema = z.object({
  body: z.object({
    title: z.string().min(3).max(150),
    instructions: z.string().min(10),
    maxScore: z.number().int().min(1).max(1000).optional(),
  }),
});

export const submitAssignmentSchema = z.object({
  body: z.object({
    contentUrl: z.string().url(),
    notes: z.string().max(2000).optional(),
  }),
});

export const gradeSubmissionSchema = z.object({
  body: z.object({
    score: z.number().int().min(0),
    feedback: z.string().max(2000).optional(),
  }),
});
