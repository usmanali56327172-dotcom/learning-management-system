import { prisma } from "@/config/prisma";
import { ApiError } from "@/utils/ApiError";
import { createNotification } from "@/modules/notifications/notifications.service";

export async function createAssignment(lessonId: string, instructorId: string, data: any) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    include: { section: { include: { course: true } } },
  });
  if (!lesson) throw ApiError.notFound("Lesson not found");
  if (lesson.section.course.instructorId !== instructorId) throw ApiError.forbidden();

  return prisma.assignment.create({
    data: { lessonId, title: data.title, instructions: data.instructions, maxScore: data.maxScore ?? 100 },
  });
}

export async function submitAssignment(userId: string, assignmentId: string, contentUrl: string, notes?: string) {
  return prisma.assignmentSubmission.upsert({
    where: { assignmentId_userId: { assignmentId, userId } },
    update: { contentUrl, notes, status: "SUBMITTED", submittedAt: new Date() },
    create: { assignmentId, userId, contentUrl, notes },
  });
}

export async function gradeSubmission(
  instructorId: string,
  submissionId: string,
  score: number,
  feedback?: string
) {
  const submission = await prisma.assignmentSubmission.findUnique({
    where: { id: submissionId },
    include: { assignment: { include: { lesson: { include: { section: { include: { course: true } } } } } } },
  });
  if (!submission) throw ApiError.notFound("Submission not found");
  if (submission.assignment.lesson.section.course.instructorId !== instructorId) throw ApiError.forbidden();

  const updated = await prisma.assignmentSubmission.update({
    where: { id: submissionId },
    data: { score, feedback, status: "GRADED", gradedAt: new Date() },
  });

  await createNotification({
    userId: submission.userId,
    type: "ASSIGNMENT_GRADED",
    title: "Assignment graded",
    message: `Your submission for "${submission.assignment.title}" has been graded: ${score}/${submission.assignment.maxScore}`,
  });

  return updated;
}

export async function listSubmissionsForAssignment(instructorId: string, assignmentId: string) {
  const assignment = await prisma.assignment.findUnique({
    where: { id: assignmentId },
    include: { lesson: { include: { section: { include: { course: true } } } } },
  });
  if (!assignment) throw ApiError.notFound("Assignment not found");
  if (assignment.lesson.section.course.instructorId !== instructorId) throw ApiError.forbidden();

  return prisma.assignmentSubmission.findMany({
    where: { assignmentId },
    include: { user: { select: { firstName: true, lastName: true, avatarUrl: true } } },
    orderBy: { submittedAt: "desc" },
  });
}
