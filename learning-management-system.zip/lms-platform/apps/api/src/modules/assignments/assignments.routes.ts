import { Router } from "express";
import { authenticate, authorize } from "@/middlewares/auth";
import { validate } from "@/middlewares/validate";
import * as controller from "./assignments.controller";
import { createAssignmentSchema, submitAssignmentSchema, gradeSubmissionSchema } from "./assignments.validation";

const router = Router();
router.use(authenticate);

router.post(
  "/lessons/:lessonId",
  authorize("INSTRUCTOR", "ADMIN"),
  validate(createAssignmentSchema),
  controller.createAssignment
);
router.post("/:assignmentId/submissions", validate(submitAssignmentSchema), controller.submitAssignment);
router.get("/:assignmentId/submissions", authorize("INSTRUCTOR", "ADMIN"), controller.listSubmissions);
router.patch(
  "/submissions/:submissionId/grade",
  authorize("INSTRUCTOR", "ADMIN"),
  validate(gradeSubmissionSchema),
  controller.gradeSubmission
);

export default router;
