import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./assignments.service";

export const createAssignment = catchAsync(async (req: Request, res: Response) => {
  const assignment = await service.createAssignment(req.params.lessonId, req.user!.id, req.body);
  sendSuccess(res, assignment, "Assignment created", 201);
});

export const submitAssignment = catchAsync(async (req: Request, res: Response) => {
  const submission = await service.submitAssignment(req.user!.id, req.params.assignmentId, req.body.contentUrl, req.body.notes);
  sendSuccess(res, submission, "Assignment submitted", 201);
});

export const gradeSubmission = catchAsync(async (req: Request, res: Response) => {
  const submission = await service.gradeSubmission(req.user!.id, req.params.submissionId, req.body.score, req.body.feedback);
  sendSuccess(res, submission, "Submission graded");
});

export const listSubmissions = catchAsync(async (req: Request, res: Response) => {
  const submissions = await service.listSubmissionsForAssignment(req.user!.id, req.params.assignmentId);
  sendSuccess(res, submissions, "Submissions fetched");
});
