import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./notifications.service";

export const list = catchAsync(async (req: Request, res: Response) => {
  const items = await service.listMyNotifications(req.user!.id, req.query.unread === "true");
  sendSuccess(res, items, "Notifications fetched");
});

export const markRead = catchAsync(async (req: Request, res: Response) => {
  await service.markAsRead(req.user!.id, req.params.id);
  sendSuccess(res, null, "Notification marked as read");
});

export const markAllRead = catchAsync(async (req: Request, res: Response) => {
  await service.markAllAsRead(req.user!.id);
  sendSuccess(res, null, "All notifications marked as read");
});
