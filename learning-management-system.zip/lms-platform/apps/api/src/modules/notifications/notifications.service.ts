import { prisma } from "@/config/prisma";
import { NotificationType } from "@prisma/client";
import { getIO } from "@/realtime/socket";

export async function createNotification(input: {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  link?: string;
}) {
  const notification = await prisma.notification.create({ data: input });

  // Push in real time if the user has an active socket connection
  try {
    getIO()?.to(`user:${input.userId}`).emit("notification:new", notification);
  } catch {
    // socket layer not initialized (e.g. in tests) — safe to ignore
  }

  return notification;
}

export async function listMyNotifications(userId: string, unreadOnly = false) {
  return prisma.notification.findMany({
    where: { userId, ...(unreadOnly ? { isRead: false } : {}) },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
}

export async function markAsRead(userId: string, id: string) {
  await prisma.notification.updateMany({ where: { id, userId }, data: { isRead: true } });
}

export async function markAllAsRead(userId: string) {
  await prisma.notification.updateMany({ where: { userId, isRead: false }, data: { isRead: true } });
}
