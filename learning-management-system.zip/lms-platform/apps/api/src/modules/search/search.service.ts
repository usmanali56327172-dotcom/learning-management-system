import { prisma } from "@/config/prisma";

export async function globalSearch(q: string) {
  if (!q || q.trim().length < 2) return { courses: [], instructors: [], categories: [] };

  const [courses, instructors, categories] = await Promise.all([
    prisma.course.findMany({
      where: {
        status: "PUBLISHED",
        OR: [
          { title: { contains: q, mode: "insensitive" } },
          { tags: { has: q.toLowerCase() } },
        ],
      },
      take: 8,
      select: { id: true, title: true, slug: true, thumbnailUrl: true, price: true, averageRating: true },
    }),
    prisma.user.findMany({
      where: {
        role: "INSTRUCTOR",
        OR: [
          { firstName: { contains: q, mode: "insensitive" } },
          { lastName: { contains: q, mode: "insensitive" } },
        ],
      },
      take: 5,
      select: { id: true, firstName: true, lastName: true, avatarUrl: true, headline: true },
    }),
    prisma.category.findMany({
      where: { name: { contains: q, mode: "insensitive" } },
      take: 5,
    }),
  ]);

  return { courses, instructors, categories };
}
