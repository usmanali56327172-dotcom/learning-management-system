import { Request, Response } from "express";
import { catchAsync } from "@/utils/catchAsync";
import { sendSuccess } from "@/utils/ApiResponse";
import * as service from "./search.service";

export const search = catchAsync(async (req: Request, res: Response) => {
  const results = await service.globalSearch((req.query.q as string) || "");
  sendSuccess(res, results, "Search results fetched");
});
