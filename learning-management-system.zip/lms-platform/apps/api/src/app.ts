import express, { Express } from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import swaggerUi from "swagger-ui-express";
import { env } from "@/config/env";
import { logger } from "@/config/logger";
import routes from "@/routes";
import { errorHandler, notFoundHandler } from "@/middlewares/errorHandler";
import { globalLimiter } from "@/middlewares/rateLimiter";
import { swaggerSpec } from "@/docs/swagger";
import { webhook } from "@/modules/payments/payments.controller";

export function createApp(): Express {
  const app = express();

  app.use(helmet());
  app.use(
    cors({
      origin: env.clientUrl,
      credentials: true,
    })
  );
  app.use(compression());
  app.use(
    morgan(env.isProd ? "combined" : "dev", {
      stream: { write: (msg) => logger.http?.(msg.trim()) ?? logger.info(msg.trim()) },
    })
  );

  // Stripe webhook needs the RAW body — must be registered before express.json()
  app.post("/api/v1/payments/webhook", express.raw({ type: "application/json" }), webhook);

  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());
  app.use(globalLimiter);

  app.get("/health", (_req, res) => res.json({ status: "ok", timestamp: new Date().toISOString() }));
  app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

  app.use("/api/v1", routes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
