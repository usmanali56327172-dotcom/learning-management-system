import { Server as HttpServer } from "http";
import { Server, Socket } from "socket.io";
import { env } from "@/config/env";
import { verifyAccessToken } from "@/utils/jwt";
import { logger } from "@/config/logger";

let io: Server | null = null;

export function initSocket(httpServer: HttpServer) {
  io = new Server(httpServer, {
    cors: { origin: env.clientUrl, credentials: true },
  });

  io.use((socket: Socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error("Authentication required"));
      const payload = verifyAccessToken(token);
      socket.data.userId = payload.sub;
      next();
    } catch {
      next(new Error("Invalid token"));
    }
  });

  io.on("connection", (socket: Socket) => {
    const userId = socket.data.userId as string;
    socket.join(`user:${userId}`);
    logger.debug(`Socket connected for user ${userId}`);

    socket.on("disconnect", () => {
      logger.debug(`Socket disconnected for user ${userId}`);
    });
  });

  return io;
}

export function getIO(): Server | null {
  return io;
}
