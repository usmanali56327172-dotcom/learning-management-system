import { PrismaClient, Role, CourseLevel, CourseStatus, LessonType } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  const passwordHash = await bcrypt.hash("Password123!", 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@lms.com" },
    update: {},
    create: {
      email: "admin@lms.com", firstName: "Ada", lastName: "Admin",
      passwordHash, role: Role.ADMIN, isEmailVerified: true,
    },
  });

  const instructor = await prisma.user.upsert({
    where: { email: "instructor@lms.com" },
    update: {},
    create: {
      email: "instructor@lms.com", firstName: "Ian", lastName: "Instructor",
      passwordHash, role: Role.INSTRUCTOR, isEmailVerified: true, instructorApproved: true,
      headline: "Senior Software Engineer & Educator",
      bio: "10+ years building scalable web applications. Teaching what I wish I'd known earlier.",
    },
  });

  const student = await prisma.user.upsert({
    where: { email: "student@lms.com" },
    update: {},
    create: {
      email: "student@lms.com", firstName: "Sam", lastName: "Student",
      passwordHash, role: Role.STUDENT, isEmailVerified: true,
    },
  });

  const category = await prisma.category.upsert({
    where: { slug: "web-development" },
    update: {},
    create: { name: "Web Development", slug: "web-development", icon: "code" },
  });

  const course = await prisma.course.upsert({
    where: { slug: "complete-react-developer-course" },
    update: {},
    create: {
      title: "The Complete React Developer Course",
      slug: "complete-react-developer-course",
      subtitle: "Build production-ready React apps from scratch",
      description:
        "A comprehensive, project-based course covering React fundamentals, hooks, state management, testing, and deployment.",
      price: 49.99,
      discountPrice: 19.99,
      level: CourseLevel.INTERMEDIATE,
      status: CourseStatus.PUBLISHED,
      publishedAt: new Date(),
      instructorId: instructor.id,
      categoryId: category.id,
      requirements: ["Basic HTML/CSS/JS knowledge", "A computer with internet access"],
      whatYouWillLearn: ["Build real-world React applications", "Master hooks and context", "Deploy to production"],
      targetAudience: ["Aspiring frontend developers", "JavaScript developers wanting to learn React"],
      tags: ["react", "javascript", "frontend", "web development"],
      thumbnailUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800",
    },
  });

  const section = await prisma.section.create({
    data: { title: "Getting Started", order: 0, courseId: course.id },
  });

  await prisma.lesson.createMany({
    data: [
      {
        title: "Course Introduction", type: LessonType.VIDEO, order: 0,
        videoUrl: "https://example.com/videos/intro.mp4", videoDuration: 300,
        isPreview: true, sectionId: section.id,
      },
      {
        title: "Setting Up Your Environment", type: LessonType.VIDEO, order: 1,
        videoUrl: "https://example.com/videos/setup.mp4", videoDuration: 600,
        sectionId: section.id,
      },
    ],
  });

  await prisma.course.update({
    where: { id: course.id },
    data: { totalLessons: 2, totalDuration: 900 },
  });

  console.log("✅ Seed complete. Demo accounts (password: Password123!):");
  console.log(`   Admin:      ${admin.email}`);
  console.log(`   Instructor: ${instructor.email}`);
  console.log(`   Student:    ${student.email}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
