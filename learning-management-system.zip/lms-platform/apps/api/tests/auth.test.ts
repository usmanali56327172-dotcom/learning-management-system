import request from "supertest";
import { createApp } from "@/app";

// NOTE: These tests assume a running test database configured via DATABASE_URL.
// In CI, run `prisma migrate deploy` against a disposable Postgres instance first.

const app = createApp();

describe("Auth API", () => {
  const testUser = {
    firstName: "Test",
    lastName: "User",
    email: `test.${Date.now()}@example.com`,
    password: "SecurePass123!",
  };

  it("registers a new user and returns an access token", async () => {
    const res = await request(app).post("/api/v1/auth/register").send(testUser);
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.accessToken).toBeDefined();
    expect(res.body.data.user.email).toBe(testUser.email);
    expect(res.body.data.user.passwordHash).toBeUndefined();
  });

  it("rejects duplicate registration", async () => {
    const res = await request(app).post("/api/v1/auth/register").send(testUser);
    expect(res.status).toBe(409);
  });

  it("rejects registration with an invalid email", async () => {
    const res = await request(app)
      .post("/api/v1/auth/register")
      .send({ ...testUser, email: "not-an-email" });
    expect(res.status).toBe(422);
  });

  it("logs in with correct credentials", async () => {
    const res = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: testUser.email, password: testUser.password });
    expect(res.status).toBe(200);
    expect(res.body.data.accessToken).toBeDefined();
  });

  it("rejects login with incorrect password", async () => {
    const res = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: testUser.email, password: "wrongpassword" });
    expect(res.status).toBe(401);
  });

  it("blocks access to a protected route without a token", async () => {
    const res = await request(app).get("/api/v1/auth/me");
    expect(res.status).toBe(401);
  });
});
