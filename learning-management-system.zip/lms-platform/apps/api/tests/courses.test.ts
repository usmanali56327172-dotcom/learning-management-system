import request from "supertest";
import { createApp } from "@/app";

const app = createApp();

describe("Courses API", () => {
  it("lists published courses with pagination metadata", async () => {
    const res = await request(app).get("/api/v1/courses?page=1&limit=5");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
    expect(res.body.meta).toHaveProperty("total");
    expect(res.body.meta).toHaveProperty("totalPages");
  });

  it("returns 404 for a non-existent course slug", async () => {
    const res = await request(app).get("/api/v1/courses/does-not-exist-xyz");
    expect(res.status).toBe(404);
  });

  it("rejects course creation without authentication", async () => {
    const res = await request(app).post("/api/v1/courses").send({
      title: "Unauthorized Course",
      description: "This should fail because there is no auth token.",
    });
    expect(res.status).toBe(401);
  });

  it("validates required fields on course creation", async () => {
    // Even with a fake token this should fail auth before validation,
    // demonstrating middleware ordering (auth guards run before handlers).
    const res = await request(app)
      .post("/api/v1/courses")
      .set("Authorization", "Bearer invalid.token.here")
      .send({ title: "x" });
    expect(res.status).toBe(401);
  });
});
