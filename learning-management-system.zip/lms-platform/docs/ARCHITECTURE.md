# Architecture

## High-level request flow

```
Browser (React SPA)
      │  fetch/axios, JWT in Authorization header, refresh token in httpOnly cookie
      ▼
Express app (app.ts)
  helmet → cors → compression → morgan → rate limiter → routes
      │
      ▼
Route (modules/<domain>/*.routes.ts)
  — wires up middleware: authenticate, authorize(role), validate(zodSchema)
      │
      ▼
Controller (modules/<domain>/*.controller.ts)
  — thin: extract req data, call service, shape the response via sendSuccess()
      │
      ▼
Service (modules/<domain>/*.service.ts)
  — all business logic and Prisma calls live here
      │
      ▼
Prisma Client → PostgreSQL
```

Errors thrown anywhere in that chain (an `ApiError`, a Zod validation error, or a Prisma known
error) are caught by `catchAsync()` and forwarded to the centralized `errorHandler` middleware,
which maps them to a consistent JSON error shape and the right HTTP status code.

## Why a service layer

Controllers never touch Prisma directly. This keeps route handlers a one-line translation between
HTTP and domain logic, and makes services reusable — e.g. `progress.service.ts` calls into
`certificates.service.ts` when a course reaches 100%, without either module knowing about Express
at all. It also means service functions can be unit tested without spinning up HTTP.

## Authentication design

- **Access token**: short-lived (15 min) JWT, sent in the `Authorization: Bearer` header, verified
  on every protected request by the `authenticate` middleware.
- **Refresh token**: longer-lived (7 days) JWT, stored **only** in an httpOnly, `SameSite=Lax`
  cookie scoped to `/api/v1/auth` — never exposed to JavaScript, which limits XSS blast radius.
  Refresh tokens are persisted in the `refresh_tokens` table so they can be revoked (logout,
  password reset invalidates all of a user's sessions) and are **rotated** on every use: each
  refresh call issues a new token and marks the old one `revoked`, so a stolen refresh token has a
  narrow window of usefulness.
- **Role-based authorization**: `authorize(...roles)` middleware checks `req.user.role` — the same
  role encoded in the access token payload — against an allow-list per route. The frontend mirrors
  this with `<ProtectedRoute allowedRoles={[...]}>` for UX (redirecting before a request is even
  made), but the API is the actual enforcement boundary.

## Data model highlights (`prisma/schema.prisma`)

- **Course → Section → Lesson** is a strict tree (1 course has many sections, each section has
  many ordered lessons). `Lesson.type` discriminates video/article/quiz/assignment; `Quiz` and
  `Assignment` are optional 1:1 extensions of a lesson rather than separate lesson types with
  duplicated fields.
- **Enrollment** is the join between `User` and `Course`, carrying `status` and `progressPct`.
  `LessonProgress` is the finer-grained per-lesson record; `progress.service.ts` recalculates the
  enrollment's `progressPct` every time a lesson is marked complete, and flips the enrollment to
  `COMPLETED` (triggering certificate issuance) once it hits 100%.
- **Certificate** has a unique `serialNumber` and a public verification endpoint
  (`GET /certificates/verify/:serialNumber`) that requires no authentication — this is what makes
  a certificate actually verifiable by a third party (e.g. an employer), not just a PDF anyone
  could fabricate.
- **Payment** records every checkout attempt (not just successful ones), keyed to a Stripe
  Checkout Session id, so webhook fulfillment is idempotent — replays of the same
  `checkout.session.completed` event won't double-enroll a student.
- **Notification** rows are the source of truth (so a user can view history after reconnecting);
  Socket.IO is used purely to push a live copy to a connected client, not as the only delivery
  mechanism.

## Real-time layer

`src/realtime/socket.ts` initializes a Socket.IO server alongside the HTTP server. Every socket
connection must present a valid access token during the handshake (`socket.handshake.auth.token`);
on success, the socket joins a room named `user:<id>`. Services that create a notification or a
chat message emit to that room (`getIO()?.to('user:<id>').emit(...)`), so any module can push a
real-time update without importing Express or knowing about the transport. If no socket is
initialized (e.g. inside a Jest test), `getIO()` returns `null` and the emit is a no-op — real-time
delivery is additive, not load-bearing.

## Payments

Stripe Checkout Sessions are created server-side (`payments.service.ts#createCheckoutSession`)
with the course price and a `metadata: { userId, courseId }` payload. The frontend redirects the
browser to the returned `checkoutUrl` — card details never touch our servers. Fulfillment
(creating the `Enrollment`, incrementing `enrollmentCount`, marking the `Payment` as `SUCCEEDED`)
happens **only** in the `checkout.session.completed` webhook handler, not in the client-side
"success" redirect — the success page is just a friendly confirmation; trusting a client-side
redirect to grant access would let anyone fake a purchase by visiting the URL directly.

## Frontend state strategy

- **Server state** (courses, enrollments, notifications, analytics, ...) lives in TanStack Query.
  Every API module in `src/api/` returns plain promises; hooks/components call `useQuery`/
  `useMutation` directly against them, get caching and automatic refetch, and invalidate related
  queries after a mutation (e.g. enrolling invalidates `["my-enrollments"]`).
- **Client/auth state** (the logged-in user, the access token, dark-mode preference) lives in two
  small Zustand stores, persisted to `localStorage` so a refresh doesn't log the user out. The
  access token is also attached to every request via an axios interceptor; a second interceptor
  catches `401` responses, attempts a silent `/auth/refresh` (using the httpOnly cookie), retries
  the original request once, and only redirects to `/login` if the refresh itself fails.

## Design system

The UI intentionally avoids the generic "AI-tool" look (cream + terracotta, or near-black +
neon). The palette is deep navy (`ink`), warm paper (`paper`/`parchment`), forest green, and a
muted gold accent — closer to an academic/editorial feel that fits a learning platform. The
signature visual motif is the "spine": a vertical gold-to-forest gradient bar on the left edge of
course cards, echoing a book's spine and doubling as a progress cue. Typography pairs a serif
display face (Fraunces) for headings with Inter for UI text.
