# API Reference

Base URL: `/api/v1`. Full interactive docs (OpenAPI/Swagger) are served at `/api-docs` when the
API is running. This document is a quick reference for the same surface.

All responses share a common envelope:

```json
{ "success": true, "message": "...", "data": { ... }, "meta": { "total": 42, "page": 1 } }
```

Errors:

```json
{ "success": false, "message": "...", "details": { } }
```

Authenticated routes expect `Authorization: Bearer <accessToken>`. The refresh token travels in an
httpOnly cookie set automatically on login/register — you never need to handle it manually from a
browser client.

## Auth — `/auth`

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/auth/register` | — | Create a STUDENT or INSTRUCTOR account |
| POST | `/auth/login` | — | Email + password login |
| POST | `/auth/refresh` | cookie | Exchange refresh cookie for a new access token (rotates the refresh token) |
| POST | `/auth/logout` | — | Revoke the current refresh token |
| POST | `/auth/forgot-password` | — | Issue a password reset token (always 200, doesn't leak existence) |
| POST | `/auth/reset-password` | — | Consume a reset token, set a new password, revoke all sessions |
| GET | `/auth/me` | ✅ | Current user's id/email/role from the access token |

## Users — `/users`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/users/me` | ✅ | Full profile |
| PATCH | `/users/me` | ✅ | Update name, headline, bio, avatar, timezone, social links |
| POST | `/users/me/change-password` | ✅ | Change password (requires current password) |
| GET | `/users/instructors/:id` | — | Public instructor profile + their published courses |

## Courses — `/courses`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/courses` | — | List published courses. Query: `page,limit,search,category,level,minPrice,maxPrice,sort,instructorId` |
| GET | `/courses/:slug` | optional | Full course detail incl. sections/lessons/reviews |
| GET | `/courses/my/courses` | Instructor/Admin | All of the caller's courses regardless of status |
| POST | `/courses` | Instructor/Admin | Create a new course (starts as `DRAFT`) |
| PATCH | `/courses/:id` | Instructor/Admin (owner) | Update course fields |
| DELETE | `/courses/:id` | Instructor/Admin (owner) | Delete a course |
| POST | `/courses/:id/submit` | Instructor (owner) | Move `DRAFT → PENDING_REVIEW` |
| POST | `/courses/:id/sections` | Instructor/Admin (owner) | Add a curriculum section |
| POST | `/courses/sections/:sectionId/lessons` | Instructor/Admin (owner) | Add a lesson to a section |

## Enrollments & progress

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/enrollments/free` | ✅ | Enroll in a $0 course |
| GET | `/enrollments/my` | ✅ | The caller's enrollments |
| GET | `/enrollments/learn/:slug` | ✅ (enrolled) | Full curriculum + per-lesson progress for the player |
| GET | `/enrollments/status/:courseId` | ✅ | Whether the caller is enrolled |
| PATCH | `/progress/lessons/:lessonId` | ✅ (enrolled) | Mark a lesson complete / update watch time |

## Quizzes — `/quizzes`

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/quizzes/lessons/:lessonId` | Instructor/Admin | Create a quiz with questions for a lesson |
| GET | `/quizzes/lessons/:lessonId` | ✅ | Fetch quiz (answers hidden) |
| POST | `/quizzes/:quizId/attempts` | ✅ | Submit answers, get scored instantly |
| GET | `/quizzes/:quizId/attempts/my` | ✅ | The caller's attempt history |

## Assignments — `/assignments`

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/assignments/lessons/:lessonId` | Instructor/Admin | Create an assignment brief |
| POST | `/assignments/:assignmentId/submissions` | ✅ | Submit work (a content URL + notes) |
| GET | `/assignments/:assignmentId/submissions` | Instructor/Admin (owner) | List submissions to grade |
| PATCH | `/assignments/submissions/:submissionId/grade` | Instructor/Admin (owner) | Score + feedback |

## Certificates — `/certificates`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/certificates/my` | ✅ | The caller's earned certificates |
| GET | `/certificates/verify/:serialNumber` | — | Public verification — no login required |

## Reviews — `/reviews`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/reviews/course/:courseId` | — | Paginated reviews for a course |
| POST | `/reviews/course/:courseId` | ✅ (enrolled) | Create/update the caller's review |
| DELETE | `/reviews/:reviewId` | ✅ (owner) | Delete own review |

## Wishlist & bookmarks

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/wishlist` | ✅ | The caller's saved courses |
| POST | `/wishlist/:courseId/toggle` | ✅ | Add/remove a course from the wishlist |
| GET | `/bookmarks` | ✅ | The caller's lesson bookmarks (optionally `?lessonId=`) |
| POST | `/bookmarks` | ✅ | Create a timestamped bookmark |
| DELETE | `/bookmarks/:id` | ✅ (owner) | Remove a bookmark |

## Payments — `/payments`

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/payments/checkout` | ✅ | Create a Stripe Checkout Session for a paid course |
| GET | `/payments/my` | ✅ | The caller's payment history |
| POST | `/payments/webhook` | Stripe signature | Fulfillment webhook (not called by clients) |

## Notifications — `/notifications`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/notifications` | ✅ | List (optionally `?unread=true`) |
| PATCH | `/notifications/:id/read` | ✅ | Mark one as read |
| PATCH | `/notifications/read-all` | ✅ | Mark all as read |

## Messaging — `/messages`

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/messages/conversations` | ✅ | Get or create a conversation with another user |
| GET | `/messages/conversations` | ✅ | List the caller's conversations with last message preview |
| GET | `/messages/conversations/:id/messages` | ✅ (participant) | Full message history (marks incoming as read) |
| POST | `/messages/conversations/:id/messages` | ✅ (participant) | Send a message (also emitted over Socket.IO) |

## Analytics — `/analytics`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/analytics/instructor` | Instructor/Admin | Revenue, students, ratings, enrollment trend for the caller's courses |
| GET | `/analytics/admin` | Admin | Platform-wide users/courses/revenue/signup trend |

## Admin — `/admin`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/admin/users` | Admin | Search/paginate all users |
| PATCH | `/admin/users/:userId/active` | Admin | Suspend/reactivate a user |
| PATCH | `/admin/users/:userId/role` | Admin | Change a user's role |
| GET | `/admin/courses/moderation` | Admin | Courses pending review |
| POST | `/admin/courses/:courseId/approve` | Admin | Publish a course |
| POST | `/admin/courses/:courseId/reject` | Admin | Reject with a reason (visible to the instructor) |
| GET | `/admin/audit-log` | Admin | Paginated log of admin actions |

## Search — `/search`

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/search?q=` | — | Combined course/instructor/category results |
