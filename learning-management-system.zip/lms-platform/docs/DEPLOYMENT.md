# Deployment Guide

This app is deployable to any Docker-friendly host. Below are two concrete paths: a fully
containerized single-VM/compose deploy, and a split managed-services deploy (usually cheaper to
start and easier to scale independently).

## Option 1 — Docker Compose on a single host

Works on any VM (DigitalOcean, Hetzner, an EC2 instance, etc.) with Docker installed.

```bash
git clone <this-repo>
cd lms-platform
cp apps/api/.env.example apps/api/.env
# edit apps/api/.env with production secrets (long random JWT secrets, real Stripe keys, SMTP creds)

docker compose up -d --build
docker compose exec api npm run prisma:seed   # optional
```

Put a reverse proxy (Caddy or nginx) in front of ports `8080` (web) and `5000` (api) for TLS
termination and a single public domain, e.g.:

```
lms.example.com        → web:8080
lms.example.com/api    → api:5000
```

Caddy example (`Caddyfile`):

```
lms.example.com {
    handle_path /api/* {
        reverse_proxy localhost:5000
    }
    reverse_proxy localhost:8080
}
```

## Option 2 — Managed services (recommended for a portfolio deploy)

| Piece | Suggested host | Notes |
|---|---|---|
| PostgreSQL | Neon, Supabase, or Railway | Free tiers available; copy the connection string into `DATABASE_URL` |
| API | Render, Railway, or Fly.io | Point the build at `apps/api`, run `npm run build` then `npm start`; run `npx prisma migrate deploy` as a release/predeploy step |
| Web | Vercel or Netlify | Point the build at `apps/web`, build command `npm run build`, output `dist`; set `VITE_API_URL` (or rely on a rewrite rule) to the deployed API URL |

### API service settings (Render/Railway example)

- Build command: `npm install && npx prisma generate && npm run build`
- Start command: `npx prisma migrate deploy && npm start`
- Environment variables: everything in `apps/api/.env.example`, with `CLIENT_URL` set to your
  deployed frontend's origin (required for CORS and Stripe redirect URLs).

### Web service settings (Vercel example)

- Root directory: `apps/web`
- Build command: `npm run build`
- Output directory: `dist`
- Add a rewrite so `/api/*` proxies to your API host (or just point the frontend at the full API
  URL and drop the Vite dev proxy in production).

### Stripe webhook

Register `https://<your-api-domain>/api/v1/payments/webhook` in the Stripe dashboard for the
`checkout.session.completed` event, and copy the generated signing secret into
`STRIPE_WEBHOOK_SECRET`. Locally, use the Stripe CLI:

```bash
stripe listen --forward-to localhost:5000/api/v1/payments/webhook
```

## Database migrations in production

Never run `prisma migrate dev` against production — it's for local schema iteration only. Use:

```bash
npx prisma migrate deploy
```

This applies committed migrations in `prisma/migrations/` without generating new ones. Run it as
a release step (Render "pre-deploy command", Railway "deploy command", or the `docker-compose`
`command:` override already wired up in this repo).

## Suggested CI pipeline (GitHub Actions)

`.github/workflows/ci.yml` in this repo runs on every push/PR:

1. Spin up a disposable Postgres service container.
2. Install API dependencies, generate the Prisma client, run `prisma migrate deploy` against the
   test database.
3. Run `npm test` (Jest + Supertest).
4. Build both the API (`tsc`) and the web app (`vite build`) to catch type errors before merge.

Extend it with a deploy job that triggers your host's deploy hook (Render/Railway both support a
simple `curl` to a deploy-hook URL) on pushes to `main`.

## Production checklist

- [ ] Rotate `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` to long random values (never reuse the
      `.env.example` placeholders).
- [ ] Set `NODE_ENV=production` so the error handler stops leaking stack traces.
- [ ] Put the API behind HTTPS (Stripe requires it for live webhooks).
- [ ] Set real SMTP credentials if you want password-reset emails to actually send.
- [ ] Point `CLIENT_URL` at your real frontend origin — it's used for CORS and for building
      Stripe success/cancel URLs.
- [ ] Enable Postgres automated backups on whichever managed provider you choose.
- [ ] Consider moving `videoUrl`/`thumbnailUrl`/avatar storage to S3-compatible object storage
      instead of arbitrary external URLs before accepting real user uploads.
